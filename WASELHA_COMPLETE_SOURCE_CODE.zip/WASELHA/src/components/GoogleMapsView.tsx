import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  APIProvider,
  AdvancedMarker,
  InfoWindow,
  Map as GoogleMap,
  Pin,
  useApiIsLoaded,
  useApiLoadingStatus,
  APILoadingStatus,
  useMap,
  useMapsLibrary,
} from '@vis.gl/react-google-maps';
import { Compass, LocateFixed, MapPin, Navigation, Search } from 'lucide-react';
import { apiRequest } from '../services/api';
import { haversineDistanceKm, type DeliveryZone } from '../types';

export interface LatLngPoint {
  lat: number;
  lng: number;
  label?: string;
}

interface RouteOverlayProps {
  origin: LatLngPoint;
  destination: LatLngPoint;
  onRouteCalculated?: (distanceKm: number, durationMin: number) => void;
}

interface MapPolylineInstance {
  setMap: (map: unknown) => void;
  setOptions: (opts: { strokeColor: string; strokeWeight: number; strokeOpacity: number }) => void;
}

interface MapCircleInstance {
  setMap: (map: unknown) => void;
}

const ZoneCirclesOverlay: React.FC<{ zones: DeliveryZone[] }> = ({ zones }) => {
  const map = useMap();
  const mapsLib = useMapsLibrary('maps');
  const circlesRef = useRef<MapCircleInstance[]>([]);

  useEffect(() => {
    if (!map || !mapsLib) return;

    circlesRef.current.forEach((c) => c.setMap(null));
    circlesRef.current = [];

    const CircleCtor = (mapsLib as unknown as { Circle?: new (opts: unknown) => MapCircleInstance })
      .Circle;
    if (!CircleCtor) return;

    const created: MapCircleInstance[] = [];
    for (const z of zones) {
      if (!z.isActive) continue;
      const circle = new CircleCtor({
        map,
        center: { lat: z.centerLat, lng: z.centerLng },
        radius: z.radiusKm * 1000,
        strokeColor: z.isCovered ? '#0284C7' : '#E11D48',
        strokeOpacity: 0.75,
        strokeWeight: 2,
        fillColor: z.isCovered ? '#06B6D4' : '#F43F5E',
        fillOpacity: z.isCovered ? 0.14 : 0.12,
        clickable: false,
      });
      created.push(circle);
    }
    circlesRef.current = created;

    return () => {
      circlesRef.current.forEach((c) => c.setMap(null));
      circlesRef.current = [];
    };
  }, [map, mapsLib, zones]);

  return null;
};

const RouteOverlay: React.FC<RouteOverlayProps> = ({
  origin,
  destination,
  onRouteCalculated,
}) => {
  const map = useMap();
  const routesLib = useMapsLibrary('routes');
  const polylinesRef = useRef<MapPolylineInstance[]>([]);

  useEffect(() => {
    if (!routesLib || !map) return;

    polylinesRef.current.forEach((p) => p.setMap(null));
    polylinesRef.current = [];

    let cancelled = false;

    const request = {
      origin: { lat: origin.lat, lng: origin.lng },
      destination: { lat: destination.lat, lng: destination.lng },
      travelMode: 'DRIVING',
      fields: ['path', 'distanceMeters', 'durationMillis', 'viewport'],
    };

    const RouteClass = routesLib.Route as unknown as {
      computeRoutes: (req: unknown) => Promise<{
        routes?: Array<{
          distanceMeters?: number;
          durationMillis?: number;
          viewport?: unknown;
          createPolylines?: () => MapPolylineInstance[];
        }>;
      }>;
    };

    if (RouteClass && typeof RouteClass.computeRoutes === 'function') {
      RouteClass.computeRoutes(request)
        .then(({ routes }) => {
          if (cancelled) return;
          const primaryRoute = routes?.[0];
          if (!primaryRoute) return;

          if (typeof primaryRoute.createPolylines === 'function') {
            const newPolylines = primaryRoute.createPolylines();
            newPolylines.forEach((polyline) => {
              polyline.setOptions({
                strokeColor: '#0284C7',
                strokeWeight: 5,
                strokeOpacity: 0.9,
              });
              polyline.setMap(map);
            });
            polylinesRef.current = newPolylines;
          }

          if (primaryRoute.viewport) {
            map.fitBounds(primaryRoute.viewport);
          }

          if (onRouteCalculated && typeof primaryRoute.distanceMeters === 'number') {
            const km = Math.round((primaryRoute.distanceMeters / 1000) * 100) / 100;
            const mins = Math.max(
              3,
              Math.round((primaryRoute.durationMillis || km * 120000) / 60000)
            );
            onRouteCalculated(km, mins);
          }
        })
        .catch(() => {
          if (cancelled) return;
          const fallbackKm = haversineDistanceKm(
            origin.lat,
            origin.lng,
            destination.lat,
            destination.lng
          );
          if (onRouteCalculated) {
            onRouteCalculated(fallbackKm, Math.max(5, Math.round(fallbackKm * 2.5)));
          }
        });
    }

    return () => {
      cancelled = true;
      polylinesRef.current.forEach((p) => p.setMap(null));
      polylinesRef.current = [];
    };
  }, [routesLib, map, origin.lat, origin.lng, destination.lat, destination.lng, onRouteCalculated]);

  return null;
};

interface InteractiveMapContentProps {
  mode: 'picker' | 'route';
  center: LatLngPoint;
  pickup?: LatLngPoint;
  delivery?: LatLngPoint;
  driver?: LatLngPoint;
  zones?: DeliveryZone[];
  onLocationPicked?: (lat: number, lng: number, address: string) => void;
  onRouteCalculated?: (distanceKm: number, durationMin: number) => void;
  heightClass: string;
}

const InteractiveMapContent: React.FC<InteractiveMapContentProps> = ({
  mode,
  center,
  pickup,
  delivery,
  driver,
  zones,
  onLocationPicked,
  onRouteCalculated,
  heightClass,
}) => {
  const isLoaded = useApiIsLoaded();
  const status = useApiLoadingStatus();
  const [selectedPin, setSelectedPin] = useState<'pickup' | 'delivery' | 'driver' | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [locating, setLocating] = useState(false);
  const [searchError, setSearchError] = useState<string | null>(null);

  const handleMapClick = useCallback(
    async (e: { detail?: { latLng?: { lat: number; lng: number } | null } }) => {
      if (mode !== 'picker' || !onLocationPicked) return;
      const latLng = e.detail?.latLng;
      if (!latLng) return;
      try {
        const res = await apiRequest<{ address: string }>('/api/maps/reverse-geocode', {
          method: 'POST',
          body: JSON.stringify({ lat: latLng.lat, lng: latLng.lng }),
        });
        onLocationPicked(latLng.lat, latLng.lng, res.address);
      } catch {
        onLocationPicked(
          latLng.lat,
          latLng.lng,
          `بغداد (${latLng.lat.toFixed(4)}, ${latLng.lng.toFixed(4)})`
        );
      }
    },
    [mode, onLocationPicked]
  );

  const handleUseCurrentGps = () => {
    if (!onLocationPicked || !navigator.geolocation) return;
    setLocating(true);
    setSearchError(null);
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const lat = pos.coords.latitude;
        const lng = pos.coords.longitude;
        try {
          const res = await apiRequest<{ address: string }>('/api/maps/reverse-geocode', {
            method: 'POST',
            body: JSON.stringify({ lat, lng }),
          });
          onLocationPicked(lat, lng, res.address);
        } catch {
          onLocationPicked(lat, lng, `موقعي الحالي (${lat.toFixed(4)}, ${lng.toFixed(4)})`);
        } finally {
          setLocating(false);
        }
      },
      () => {
        setLocating(false);
        setSearchError('تعذر الوصول إلى GPS. يمكنك النقر مباشرة على الخريطة لتحديد الموقع.');
      },
      { enableHighAccuracy: true, timeout: 8000 }
    );
  };

  const handleSearchAddress = async () => {
    if (!searchQuery.trim() || !onLocationPicked) return;
    setLocating(true);
    setSearchError(null);
    try {
      const res = await apiRequest<{
        lat: number;
        lng: number;
        formattedAddress: string;
      }>('/api/maps/geocode', {
        method: 'POST',
        body: JSON.stringify({ address: searchQuery.trim() }),
      });
      onLocationPicked(res.lat, res.lng, res.formattedAddress);
    } catch (err) {
      setSearchError(err instanceof Error ? err.message : 'لم يتم العثور على العنوان.');
    } finally {
      setLocating(false);
    }
  };

  if (status === APILoadingStatus.FAILED || status === APILoadingStatus.AUTH_FAILURE) {
    return (
      <div
        className={`${heightClass} w-full rounded-2xl border border-slate-200 bg-slate-50 flex flex-col items-center justify-center p-4 text-center`}
      >
        <MapPin className="w-8 h-8 text-sky-600 mb-2" />
        <p className="text-sm font-semibold text-slate-800">تعذر تحميل خرائط جوجل حالياً</p>
        <p className="text-xs text-slate-500 mt-1">
          يتم استخدام حساب المنطقة والمسافة الجغرافية تلقائياً لضمان استمرار الطلب.
        </p>
        {mode === 'picker' && onLocationPicked && (
          <button
            type="button"
            onClick={handleUseCurrentGps}
            className="mt-3 min-h-[40px] inline-flex items-center gap-2 rounded-xl bg-sky-600 px-4 py-2 text-xs font-semibold text-white hover:bg-sky-700 cursor-pointer"
          >
            <LocateFixed className="w-4 h-4" />
            <span>استخدام موقعي الحالي GPS</span>
          </button>
        )}
      </div>
    );
  }

  return (
    <div className="space-y-2.5">
      {mode === 'picker' && onLocationPicked && (
        <div className="flex flex-col sm:flex-row gap-2">
          <div className="flex-1 flex gap-2">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    e.stopPropagation();
                    void handleSearchAddress();
                  }
                }}
                placeholder="ابحث عن حي أو شارع (مثال: المنصور، الكرادة)..."
                className="w-full min-h-[44px] rounded-xl border border-slate-200 bg-white pr-9 pl-3 text-sm text-slate-900 placeholder:text-slate-400 focus:border-sky-500 focus:outline-none"
              />
            </div>
            <button
              type="button"
              onClick={() => void handleSearchAddress()}
              disabled={locating}
              className="min-h-[44px] px-4 rounded-xl bg-slate-900 text-white text-xs font-semibold hover:bg-slate-800 whitespace-nowrap shrink-0 cursor-pointer disabled:opacity-60"
            >
              بحث
            </button>
          </div>
          <button
            type="button"
            onClick={handleUseCurrentGps}
            disabled={locating}
            className="min-h-[44px] inline-flex items-center justify-center gap-2 rounded-xl bg-sky-50 border border-sky-200 px-3.5 text-xs font-semibold text-sky-700 hover:bg-sky-100 whitespace-nowrap shrink-0 cursor-pointer disabled:opacity-60"
          >
            <LocateFixed className="w-4 h-4" />
            <span>{locating ? 'جاري التحديد...' : 'موقعي GPS'}</span>
          </button>
        </div>
      )}

      {searchError && (
        <p className="text-xs text-amber-700 bg-amber-50 border border-amber-200 rounded-xl px-3 py-2">
          {searchError}
        </p>
      )}

      <div
        className={`${heightClass} w-full rounded-2xl overflow-hidden border border-slate-200 relative bg-slate-100`}
      >
        {!isLoaded && (
          <div className="absolute inset-0 z-10 flex flex-col items-center justify-center bg-slate-100/90">
            <div className="w-7 h-7 rounded-full border-3 border-sky-200 border-t-sky-600 animate-spin" />
            <span className="mt-2 text-xs font-medium text-slate-600">جاري تحميل الخريطة...</span>
          </div>
        )}
        <GoogleMap
          mapId="DEMO_MAP_ID"
          defaultCenter={{ lat: center.lat, lng: center.lng }}
          center={mode === 'picker' ? { lat: center.lat, lng: center.lng } : undefined}
          defaultZoom={12}
          gestureHandling="greedy"
          disableDefaultUI={false}
          streetViewControl={false}
          mapTypeControl={false}
          internalUsageAttributionIds={['gmp_mcp_codeassist_v1_aistudio']}
          onClick={handleMapClick}
          style={{ width: '100%', height: '100%' }}
        >
          {zones && zones.length > 0 && <ZoneCirclesOverlay zones={zones} />}

          {pickup && (
            <AdvancedMarker
              position={{ lat: pickup.lat, lng: pickup.lng }}
              title={pickup.label || 'موقع المتجر'}
              onClick={() => setSelectedPin('pickup')}
            >
              <Pin background="#0284C7" borderColor="#0369A1" glyphColor="#FFFFFF" />
            </AdvancedMarker>
          )}

          {delivery && (
            <AdvancedMarker
              position={{ lat: delivery.lat, lng: delivery.lng }}
              title={delivery.label || 'موقع التوصيل'}
              onClick={() => setSelectedPin('delivery')}
            >
              <Pin background="#06B6D4" borderColor="#0E7490" glyphColor="#FFFFFF" />
            </AdvancedMarker>
          )}

          {driver && (
            <AdvancedMarker
              position={{ lat: driver.lat, lng: driver.lng }}
              title={driver.label || 'موقع المندوب'}
              onClick={() => setSelectedPin('driver')}
            >
              <div className="flex items-center justify-center w-9 h-9 rounded-full bg-slate-900 text-cyan-300 border-2 border-white shadow-lg">
                <Navigation className="w-4 h-4" />
              </div>
            </AdvancedMarker>
          )}

          {mode === 'route' && pickup && delivery && (
            <RouteOverlay
              origin={pickup}
              destination={delivery}
              onRouteCalculated={onRouteCalculated}
            />
          )}

          {selectedPin === 'pickup' && pickup && (
            <InfoWindow
              position={{ lat: pickup.lat, lng: pickup.lng }}
              onCloseClick={() => setSelectedPin(null)}
            >
              <div className="text-xs font-semibold text-slate-900 px-1 py-0.5">
                {pickup.label || 'نقطة الاستلام (المتجر)'}
              </div>
            </InfoWindow>
          )}

          {selectedPin === 'delivery' && delivery && (
            <InfoWindow
              position={{ lat: delivery.lat, lng: delivery.lng }}
              onCloseClick={() => setSelectedPin(null)}
            >
              <div className="text-xs font-semibold text-slate-900 px-1 py-0.5">
                {delivery.label || 'نقطة التسليم (الزبون)'}
              </div>
            </InfoWindow>
          )}

          {selectedPin === 'driver' && driver && (
            <InfoWindow
              position={{ lat: driver.lat, lng: driver.lng }}
              onCloseClick={() => setSelectedPin(null)}
            >
              <div className="text-xs font-semibold text-slate-900 px-1 py-0.5">
                {driver.label || 'موقع المندوب المباشر'}
              </div>
            </InfoWindow>
          )}
        </GoogleMap>
      </div>

      {mode === 'picker' && (
        <p className="text-xs text-slate-500 flex items-center gap-1.5">
          <Compass className="w-3.5 h-3.5 text-sky-600 shrink-0" />
          <span>انقر على أي نقطة في الخريطة لتعيين الموقع الدقيق للتوصيل أو المنطقة.</span>
        </p>
      )}
    </div>
  );
};

export interface GoogleMapsViewProps {
  apiKey: string;
  mode: 'picker' | 'route';
  center: LatLngPoint;
  pickup?: LatLngPoint;
  delivery?: LatLngPoint;
  driver?: LatLngPoint;
  zones?: DeliveryZone[];
  onLocationPicked?: (lat: number, lng: number, address: string) => void;
  onRouteCalculated?: (distanceKm: number, durationMin: number) => void;
  heightClass?: string;
}

export const GoogleMapsView: React.FC<GoogleMapsViewProps> = ({
  apiKey,
  mode,
  center,
  pickup,
  delivery,
  driver,
  zones,
  onLocationPicked,
  onRouteCalculated,
  heightClass = 'h-64',
}) => {
  if (!apiKey) {
    return (
      <div
        className={`${heightClass} w-full rounded-2xl border border-slate-200 bg-slate-50 flex flex-col items-center justify-center p-4 text-center`}
      >
        <MapPin className="w-7 h-7 text-sky-600 mb-2" />
        <p className="text-sm font-semibold text-slate-800">خريطة التوصيل التفاعلية</p>
        <p className="text-xs text-slate-500 mt-1">
          مفتاح خرائط جوجل قيد التهيئة. يمكنك استخدام الإحداثيات وحساب المنطقة والمسافة التلقائي.
        </p>
      </div>
    );
  }

  return (
    <APIProvider apiKey={apiKey} language="ar" region="IQ" libraries={['marker', 'routes', 'maps']}>
      <InteractiveMapContent
        mode={mode}
        center={center}
        pickup={pickup}
        delivery={delivery}
        driver={driver}
        zones={zones}
        onLocationPicked={onLocationPicked}
        onRouteCalculated={onRouteCalculated}
        heightClass={heightClass}
      />
    </APIProvider>
  );
};
