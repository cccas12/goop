import React, { useCallback, useEffect, useState } from 'react';
import {
  ArrowLeftRight,
  BarChart3,
  CheckCircle2,
  Cloud,
  DatabaseBackup,
  DollarSign,
  Download,
  Edit3,
  LogOut,
  MapPin,
  Package,
  Plus,
  RotateCcw,
  Settings,
  ShieldCheck,
  Smartphone,
  Trash2,
  Truck,
  Users,
} from 'lucide-react';
import {
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { signInWithPopup, signOut } from 'firebase/auth';
import { auth, googleProvider } from '../firebase';
import { apiRequest, resolveApiUrl, setStoredToken } from '../services/api';
import {
  deleteZoneFromFirestore,
  deleteZoneRouteFromFirestore,
  syncPricingToFirestore,
  syncSignedInUserToFirestore,
  syncZoneRouteToFirestore,
  syncZoneToFirestore,
} from '../services/firestoreSync';
import {
  formatIqd,
  type AccountStatus,
  type BackupInfo,
  type DeliveryZone,
  type Driver,
  type Order,
  type OrderStatus,
  type PricingSettings,
  type UserAccount,
  type ZonePricingMode,
  type ZoneRouteRate,
} from '../types';
import { ORDER_STATUS_META, SENDER_TYPE_LABELS, VEHICLE_TYPE_LABELS } from '../utils/orderStatus';
import { GoogleMapsView } from './GoogleMapsView';

interface AdminOverviewData {
  users: UserAccount[];
  drivers: Driver[];
  orders: Order[];
  zones: DeliveryZone[];
  routeRates: ZoneRouteRate[];
  backups: BackupInfo[];
  settings: PricingSettings;
  analytics: {
    totalOrders: number;
    deliveredCount: number;
    activeCount: number;
    totalDeliveryFeesIqd: number;
    totalPlatformRevenueIqd: number;
    totalDriverEarningsIqd: number;
    statusCounts: Record<string, number>;
    zonePerformance: Array<{
      id: string;
      name: string;
      ordersCount: number;
      revenueIqd: number;
    }>;
  };
}

interface AdminSectionProps {
  currentUser: UserAccount | null;
  realtimeTick: number;
  firebaseEmail: string | null;
  mapsApiKey: string;
  onAuthChange: () => Promise<void>;
  onSettingsUpdated: () => Promise<void>;
}

export const AdminSection: React.FC<AdminSectionProps> = ({
  currentUser,
  realtimeTick,
  firebaseEmail,
  mapsApiKey,
  onAuthChange,
  onSettingsUpdated,
}) => {
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [loginError, setLoginError] = useState<string | null>(null);
  const [loginLoading, setLoginLoading] = useState(false);

  const [adminTab, setAdminTab] = useState<'reports' | 'zones' | 'orders' | 'users' | 'pricing'>(
    'reports'
  );
  const [overview, setOverview] = useState<AdminOverviewData | null>(null);
  const [loadingOverview, setLoadingOverview] = useState(false);
  const [actionMsg, setActionMsg] = useState<string | null>(null);

  // Global Pricing Form State (loaded dynamically from DB)
  const [baseFeeIqd, setBaseFeeIqd] = useState(0);
  const [perKmFeeIqd, setPerKmFeeIqd] = useState(0);
  const [minFeeIqd, setMinFeeIqd] = useState(0);
  const [maxFeeIqd, setMaxFeeIqd] = useState(0);
  const [interZoneFeeIqd, setInterZoneFeeIqd] = useState(0);
  const [longDistanceThresholdKm, setLongDistanceThresholdKm] = useState(0);
  const [longDistancePerKmFeeIqd, setLongDistancePerKmFeeIqd] = useState(0);
  const [platformCommissionPct, setPlatformCommissionPct] = useState(25);
  const [outsideZonesAllowed, setOutsideZonesAllowed] = useState(true);
  const [outsideZoneSurchargeIqd, setOutsideZoneSurchargeIqd] = useState(0);
  const [appName, setAppName] = useState('وصلها - WASELHA');
  const [supportPhone, setSupportPhone] = useState('');
  const [maintenanceMode, setMaintenanceMode] = useState(false);
  const [savingPricing, setSavingPricing] = useState(false);

  // Zone Editor Form State
  const [editingZoneId, setEditingZoneId] = useState<string | null>(null);
  const [zoneName, setZoneName] = useState('');
  const [zoneCity, setZoneCity] = useState('بغداد');
  const [zoneLat, setZoneLat] = useState(33.3152);
  const [zoneLng, setZoneLng] = useState(44.3661);
  const [zoneRadiusKm, setZoneRadiusKm] = useState(4.5);
  const [zonePricingMode, setZonePricingMode] = useState<ZonePricingMode>('fixed');
  const [zoneFixedFee, setZoneFixedFee] = useState(3500);
  const [zoneBaseFee, setZoneBaseFee] = useState(2500);
  const [zonePerKmFee, setZonePerKmFee] = useState(750);
  const [zoneIsCovered, setZoneIsCovered] = useState(true);
  const [zoneIsActive, setZoneIsActive] = useState(true);
  const [zoneNotes, setZoneNotes] = useState('');
  const [savingZone, setSavingZone] = useState(false);

  // Zone-to-Zone Route Matrix Form State
  const [routeFromZoneId, setRouteFromZoneId] = useState('');
  const [routeToZoneId, setRouteToZoneId] = useState('');
  const [routeFeeIqd, setRouteFeeIqd] = useState(6000);
  const [routeBidirectional, setRouteBidirectional] = useState(true);
  const [routeNotes, setRouteNotes] = useState('');
  const [savingRoute, setSavingRoute] = useState(false);

  // Backup State
  const [backupBusy, setBackupBusy] = useState(false);

  const isSuperAdmin = currentUser?.role === 'super_admin';

  const loadOverview = useCallback(async () => {
    if (!isSuperAdmin) return;
    setLoadingOverview(true);
    try {
      const data = await apiRequest<AdminOverviewData>('/api/admin/overview');
      setOverview(data);
      setBaseFeeIqd(data.settings.baseFeeIqd);
      setPerKmFeeIqd(data.settings.perKmFeeIqd);
      setMinFeeIqd(data.settings.minFeeIqd);
      setMaxFeeIqd(data.settings.maxFeeIqd);
      setInterZoneFeeIqd(data.settings.interZoneFeeIqd);
      setLongDistanceThresholdKm(data.settings.longDistanceThresholdKm);
      setLongDistancePerKmFeeIqd(data.settings.longDistancePerKmFeeIqd);
      setPlatformCommissionPct(data.settings.platformCommissionPct);
      setOutsideZonesAllowed(data.settings.outsideZonesAllowed);
      setOutsideZoneSurchargeIqd(data.settings.outsideZoneSurchargeIqd);
      setAppName(data.settings.appName);
      setSupportPhone(data.settings.supportPhone);
      setMaintenanceMode(data.settings.maintenanceMode);

      if (!routeFromZoneId && data.zones[0]) setRouteFromZoneId(data.zones[0].id);
      if (!routeToZoneId && data.zones[1]) setRouteToZoneId(data.zones[1].id);
    } catch (err) {
      setActionMsg(err instanceof Error ? err.message : 'تعذر تحميل بيانات الإدارة.');
    } finally {
      setLoadingOverview(false);
    }
  }, [isSuperAdmin, routeFromZoneId, routeToZoneId]);

  useEffect(() => {
    void loadOverview();
  }, [loadOverview, realtimeTick]);

  const handleAdminLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginLoading(true);
    setLoginError(null);
    try {
      const res = await apiRequest<{ token: string; user: UserAccount }>('/api/auth/login', {
        method: 'POST',
        body: JSON.stringify({ phone: phone.trim(), password }),
      });
      if (res.user.role !== 'super_admin') {
        setLoginError('هذا الحساب لا يملك صلاحية المدير العام (Super Admin).');
        setLoginLoading(false);
        return;
      }
      setStoredToken(res.token);
      setPassword('');
      await onAuthChange();
    } catch (err) {
      setLoginError(err instanceof Error ? err.message : 'بيانات الدخول غير صحيحة.');
    } finally {
      setLoginLoading(false);
    }
  };

  const handleLogout = async () => {
    await apiRequest('/api/auth/logout', { method: 'POST' });
    setStoredToken(null);
    await onAuthChange();
  };

  const handleGoogleCloudConnect = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
      await syncSignedInUserToFirestore();
      setActionMsg('تم ربط حساب Google Cloud Firestore بنجاح.');
    } catch (err) {
      setActionMsg(
        err instanceof Error ? err.message : 'تعذر إتمام ربط Google Sign-In في هذه النافذة.'
      );
    }
  };

  const resetZoneForm = () => {
    setEditingZoneId(null);
    setZoneName('');
    setZoneCity('بغداد');
    setZoneLat(33.3152);
    setZoneLng(44.3661);
    setZoneRadiusKm(4.5);
    setZonePricingMode('fixed');
    setZoneFixedFee(baseFeeIqd || 3500);
    setZoneBaseFee(baseFeeIqd || 2500);
    setZonePerKmFee(perKmFeeIqd || 750);
    setZoneIsCovered(true);
    setZoneIsActive(true);
    setZoneNotes('');
  };

  const startEditZone = (zone: DeliveryZone) => {
    setEditingZoneId(zone.id);
    setZoneName(zone.name);
    setZoneCity(zone.city);
    setZoneLat(zone.centerLat);
    setZoneLng(zone.centerLng);
    setZoneRadiusKm(zone.radiusKm);
    setZonePricingMode(zone.pricingMode);
    setZoneFixedFee(zone.fixedFeeIqd);
    setZoneBaseFee(zone.baseFeeIqd);
    setZonePerKmFee(zone.perKmFeeIqd);
    setZoneIsCovered(zone.isCovered);
    setZoneIsActive(zone.isActive);
    setZoneNotes(zone.notes || '');
  };

  const handleSaveZone = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingZone(true);
    setActionMsg(null);
    try {
      const payload = {
        name: zoneName.trim(),
        city: zoneCity.trim(),
        centerLat: Number(zoneLat),
        centerLng: Number(zoneLng),
        radiusKm: Number(zoneRadiusKm),
        pricingMode: zonePricingMode,
        fixedFeeIqd: Number(zoneFixedFee),
        baseFeeIqd: Number(zoneBaseFee),
        perKmFeeIqd: Number(zonePerKmFee),
        isCovered: zoneIsCovered,
        isActive: zoneIsActive,
        notes: zoneNotes.trim(),
      };
      const res = editingZoneId
        ? await apiRequest<{ zone: DeliveryZone }>(`/api/admin/zones/${editingZoneId}`, {
            method: 'PATCH',
            body: JSON.stringify(payload),
          })
        : await apiRequest<{ zone: DeliveryZone }>('/api/admin/zones', {
            method: 'POST',
            body: JSON.stringify(payload),
          });

      if (auth.currentUser) {
        await syncZoneToFirestore(res.zone).catch(() => {});
      }
      setActionMsg(
        editingZoneId
          ? `تم تحديث منطقة (${res.zone.name}) وتعميم الأسعار فوراً على جميع التطبيقات.`
          : `تمت إضافة منطقة (${res.zone.name}) وتفعيلها في التطبيقات الثلاثة.`
      );
      resetZoneForm();
      await loadOverview();
      await onSettingsUpdated();
    } catch (err) {
      setActionMsg(err instanceof Error ? err.message : 'تعذر حفظ بيانات المنطقة.');
    } finally {
      setSavingZone(false);
    }
  };

  const handleToggleZoneCoverage = async (zone: DeliveryZone) => {
    try {
      const res = await apiRequest<{ zone: DeliveryZone }>(`/api/admin/zones/${zone.id}`, {
        method: 'PATCH',
        body: JSON.stringify({ isCovered: !zone.isCovered }),
      });
      if (auth.currentUser) {
        await syncZoneToFirestore(res.zone).catch(() => {});
      }
      setActionMsg(
        res.zone.isCovered
          ? `تم فتح التغطية في منطقة (${res.zone.name}).`
          : `تم إيقاف التغطية مؤقتاً في منطقة (${res.zone.name}).`
      );
      await loadOverview();
      await onSettingsUpdated();
    } catch (err) {
      setActionMsg(err instanceof Error ? err.message : 'تعذر تحديث تغطية المنطقة.');
    }
  };

  const handleDeleteZone = async (zone: DeliveryZone) => {
    try {
      await apiRequest(`/api/admin/zones/${zone.id}`, { method: 'DELETE' });
      if (auth.currentUser) {
        await deleteZoneFromFirestore(zone.id).catch(() => {});
      }
      if (editingZoneId === zone.id) resetZoneForm();
      setActionMsg(`تم حذف منطقة (${zone.name}) وتحديث التطبيقات فوراً.`);
      await loadOverview();
      await onSettingsUpdated();
    } catch (err) {
      setActionMsg(err instanceof Error ? err.message : 'تعذر حذف المنطقة.');
    }
  };

  const handleSaveRouteRate = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingRoute(true);
    setActionMsg(null);
    try {
      const res = await apiRequest<{ route: ZoneRouteRate }>('/api/admin/routes', {
        method: 'POST',
        body: JSON.stringify({
          fromZoneId: routeFromZoneId,
          toZoneId: routeToZoneId,
          feeIqd: Number(routeFeeIqd),
          bidirectional: routeBidirectional,
          isActive: true,
          notes: routeNotes.trim() || undefined,
        }),
      });
      if (auth.currentUser) {
        await syncZoneRouteToFirestore(res.route).catch(() => {});
      }
      setRouteNotes('');
      setActionMsg(
        `تم حفظ أجرة الانتقال (${res.route.fromZoneName} ↔ ${res.route.toZoneName}) بمبلغ ${formatIqd(res.route.feeIqd)} وتحديث التطبيقات فوراً.`
      );
      await loadOverview();
      await onSettingsUpdated();
    } catch (err) {
      setActionMsg(err instanceof Error ? err.message : 'تعذر حفظ أجرة الانتقال بين المنطقتين.');
    } finally {
      setSavingRoute(false);
    }
  };

  const handleToggleRouteActive = async (route: ZoneRouteRate) => {
    try {
      const res = await apiRequest<{ route: ZoneRouteRate }>(`/api/admin/routes/${route.id}`, {
        method: 'PATCH',
        body: JSON.stringify({ isActive: !route.isActive }),
      });
      if (auth.currentUser) {
        await syncZoneRouteToFirestore(res.route).catch(() => {});
      }
      await loadOverview();
      await onSettingsUpdated();
    } catch (err) {
      setActionMsg(err instanceof Error ? err.message : 'تعذر تحديث حالة المسار.');
    }
  };

  const handleDeleteRoute = async (route: ZoneRouteRate) => {
    try {
      await apiRequest(`/api/admin/routes/${route.id}`, { method: 'DELETE' });
      if (auth.currentUser) {
        await deleteZoneRouteFromFirestore(route.id).catch(() => {});
      }
      setActionMsg(`تم حذف تسعيرة (${route.fromZoneName} ↔ ${route.toZoneName}).`);
      await loadOverview();
      await onSettingsUpdated();
    } catch (err) {
      setActionMsg(err instanceof Error ? err.message : 'تعذر حذف تسعيرة المسار.');
    }
  };

  const handleToggleUserStatus = async (userId: string, nextStatus: AccountStatus) => {
    try {
      await apiRequest(`/api/admin/users/${userId}/status`, {
        method: 'PATCH',
        body: JSON.stringify({ status: nextStatus }),
      });
      setActionMsg(nextStatus === 'suspended' ? 'تم إيقاف الحساب.' : 'تم تفعيل الحساب بنجاح.');
      await loadOverview();
      await onSettingsUpdated();
    } catch (err) {
      setActionMsg(err instanceof Error ? err.message : 'تعذر تحديث حالة الحساب.');
    }
  };

  const handleAdminOrderUpdate = async (
    orderId: string,
    payload: { status?: OrderStatus; driverId?: string }
  ) => {
    try {
      await apiRequest(`/api/admin/orders/${orderId}`, {
        method: 'PATCH',
        body: JSON.stringify(payload),
      });
      setActionMsg('تم تحديث الطلب وإخطار الأطراف لحظياً.');
      await loadOverview();
    } catch (err) {
      setActionMsg(err instanceof Error ? err.message : 'تعذر تحديث الطلب.');
    }
  };

  const handleSavePricing = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingPricing(true);
    setActionMsg(null);
    try {
      const res = await apiRequest<{ settings: PricingSettings }>('/api/admin/pricing', {
        method: 'PUT',
        body: JSON.stringify({
          baseFeeIqd: Number(baseFeeIqd),
          perKmFeeIqd: Number(perKmFeeIqd),
          minFeeIqd: Number(minFeeIqd),
          maxFeeIqd: Number(maxFeeIqd),
          interZoneFeeIqd: Number(interZoneFeeIqd),
          longDistanceThresholdKm: Number(longDistanceThresholdKm),
          longDistancePerKmFeeIqd: Number(longDistancePerKmFeeIqd),
          platformCommissionPct: Number(platformCommissionPct),
          outsideZonesAllowed,
          outsideZoneSurchargeIqd: Number(outsideZoneSurchargeIqd),
          appName,
          supportPhone,
          maintenanceMode,
        }),
      });
      if (auth.currentUser) {
        await syncPricingToFirestore(res.settings).catch(() => {});
      }
      setActionMsg('تم حفظ تسعيرة التوصيل وإعدادات المنصة وتحديث التطبيقات الثلاثة فوراً.');
      await loadOverview();
      await onSettingsUpdated();
    } catch (err) {
      setActionMsg(err instanceof Error ? err.message : 'تعذر حفظ الإعدادات.');
    } finally {
      setSavingPricing(false);
    }
  };

  const handleCreateBackup = async () => {
    setBackupBusy(true);
    try {
      await apiRequest('/api/admin/backups', { method: 'POST' });
      setActionMsg('تم إنشاء نسخة احتياطية كاملة لقاعدة البيانات وحفظها بأمان.');
      await loadOverview();
    } catch (err) {
      setActionMsg(err instanceof Error ? err.message : 'تعذر إنشاء النسخة الاحتياطية.');
    } finally {
      setBackupBusy(false);
    }
  };

  const handleRestoreBackup = async (filename: string) => {
    setBackupBusy(true);
    try {
      await apiRequest('/api/admin/backups/restore', {
        method: 'POST',
        body: JSON.stringify({ filename }),
      });
      setActionMsg('تمت استعادة النسخة الاحتياطية بنجاح وتحديث التطبيقات.');
      await loadOverview();
      await onSettingsUpdated();
    } catch (err) {
      setActionMsg(err instanceof Error ? err.message : 'تعذر استعادة النسخة الاحتياطية.');
    } finally {
      setBackupBusy(false);
    }
  };

  if (!isSuperAdmin) {
    return (
      <div className="max-w-md mx-auto rounded-3xl border border-slate-200 bg-white p-6 sm:p-8 space-y-6">
        <div className="text-center space-y-2">
          <div className="w-14 h-14 rounded-2xl bg-slate-900 text-cyan-300 flex items-center justify-center mx-auto">
            <ShieldCheck className="w-7 h-7" />
          </div>
          <h2 className="text-xl font-extrabold text-slate-900">
            تطبيق الإدارة — WASELHA MANAGER
          </h2>
          <p className="text-sm text-slate-500">
            الدخول محصور بحساب المدير العام المصرح له فقط (Super Admin).
          </p>
        </div>

        <form onSubmit={handleAdminLogin} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              رقم هاتف المدير
            </label>
            <input
              type="tel"
              required
              dir="ltr"
              autoComplete="username"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="07XXXXXXXXX"
              className="w-full min-h-[44px] rounded-xl border border-slate-200 px-3 text-sm text-left font-mono-num focus:border-sky-500 focus:outline-none"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">رمز الدخول</label>
            <input
              type="password"
              required
              autoComplete="current-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••••••"
              className="w-full min-h-[44px] rounded-xl border border-slate-200 px-3 text-sm focus:border-sky-500 focus:outline-none"
            />
          </div>

          {loginError && (
            <div className="rounded-xl bg-rose-50 border border-rose-200 px-3.5 py-2.5 text-xs font-semibold text-rose-700">
              {loginError}
            </div>
          )}

          <button
            type="submit"
            disabled={loginLoading}
            className="w-full min-h-[46px] rounded-xl bg-slate-900 text-white font-bold text-sm hover:bg-slate-800 cursor-pointer disabled:opacity-50"
          >
            {loginLoading ? 'جاري التحقق المشفر...' : 'دخول المدير العام'}
          </button>
        </form>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Super Admin Top Bar */}
      <div className="rounded-2xl border border-slate-200 bg-white p-5 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-xl bg-slate-900 text-cyan-300 flex items-center justify-center">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-extrabold text-slate-900">
              مركز قيادة وصلها — Super Admin
            </h2>
            <p className="text-xs text-slate-500 font-mono-num">
              {currentUser!.phone} · تحكم كامل بالمناطق، تسعيرة الانتقال، المسافات البعيدة، والأرباح
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          {firebaseEmail ? (
            <div className="flex items-center gap-2 rounded-xl border border-emerald-200 bg-emerald-50 px-3 py-2 text-xs font-semibold text-emerald-800">
              <Cloud className="w-4 h-4" />
              <span>مزامنة Firestore: {firebaseEmail}</span>
              <button
                type="button"
                onClick={() => signOut(auth)}
                className="underline mr-1 cursor-pointer"
              >
                فصل
              </button>
            </div>
          ) : (
            <button
              type="button"
              onClick={handleGoogleCloudConnect}
              className="min-h-[40px] inline-flex items-center gap-2 rounded-xl border border-sky-200 bg-sky-50 px-3.5 text-xs font-semibold text-sky-800 hover:bg-sky-100 cursor-pointer"
            >
              <Cloud className="w-4 h-4" />
              <span>ربط مزامنة Google Firestore</span>
            </button>
          )}

          <button
            type="button"
            onClick={handleLogout}
            className="min-h-[40px] inline-flex items-center gap-1.5 rounded-xl border border-rose-200 bg-rose-50 px-3 text-xs font-semibold text-rose-700 hover:bg-rose-100 cursor-pointer"
          >
            <LogOut className="w-4 h-4" />
            <span>خروج</span>
          </button>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto p-1 bg-slate-200/70 rounded-xl">
        {(
          [
            { key: 'reports', label: 'التقارير والأرباح (25% / 75%)', icon: BarChart3 },
            { key: 'zones', label: 'المناطق وجدول الانتقال', icon: MapPin },
            { key: 'orders', label: 'طلبات التوصيل', icon: Package },
            { key: 'users', label: 'المندوبون والزبائن والمحلات', icon: Users },
            { key: 'pricing', label: 'المسافات البعيدة والنسخ الاحتياطي', icon: Settings },
          ] as const
        ).map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.key}
              type="button"
              onClick={() => setAdminTab(tab.key)}
              className={`min-h-[40px] inline-flex items-center gap-2 px-4 py-2 rounded-lg text-xs sm:text-sm font-semibold whitespace-nowrap shrink-0 cursor-pointer transition-colors ${
                adminTab === tab.key
                  ? 'bg-white text-sky-700 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {actionMsg && (
        <div className="rounded-xl bg-sky-50 border border-sky-200 px-4 py-3 text-xs font-semibold text-sky-900 flex items-center justify-between">
          <span>{actionMsg}</span>
          <button
            type="button"
            onClick={() => setActionMsg(null)}
            className="underline cursor-pointer"
          >
            إخفاء
          </button>
        </div>
      )}

      {loadingOverview && !overview ? (
        <div className="rounded-2xl border border-slate-200 bg-white p-12 text-center text-sm text-slate-500">
          جاري تحميل التقارير والبيانات...
        </div>
      ) : null}

      {/* TAB 1: REPORTS & 25% / 75% ANALYTICS */}
      {overview && adminTab === 'reports' && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="rounded-2xl border border-slate-200 bg-white p-4">
              <div className="text-xs text-slate-500 flex items-center gap-1.5">
                <DollarSign className="w-4 h-4 text-sky-600" />
                <span>إجمالي أجور التوصيل المكتملة</span>
              </div>
              <div className="mt-2 text-2xl font-extrabold text-slate-900 font-mono-num">
                {formatIqd(overview.analytics.totalDeliveryFeesIqd)}
              </div>
            </div>
            <div className="rounded-2xl border border-slate-200 bg-white p-4">
              <div className="text-xs text-slate-500 flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>حصة وصلها ({overview.settings.platformCommissionPct}%)</span>
              </div>
              <div className="mt-2 text-2xl font-extrabold text-emerald-700 font-mono-num">
                {formatIqd(overview.analytics.totalPlatformRevenueIqd)}
              </div>
            </div>
            <div className="rounded-2xl border border-slate-200 bg-white p-4">
              <div className="text-xs text-slate-500 flex items-center gap-1.5">
                <Truck className="w-4 h-4 text-cyan-600" />
                <span>مستحقات المندوبين ({100 - overview.settings.platformCommissionPct}%)</span>
              </div>
              <div className="mt-2 text-2xl font-extrabold text-sky-700 font-mono-num">
                {formatIqd(overview.analytics.totalDriverEarningsIqd)}
              </div>
            </div>
            <div className="rounded-2xl border border-slate-200 bg-white p-4">
              <div className="text-xs text-slate-500 flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-amber-600" />
                <span>طلبات التوصيل (مكتمل / الكل)</span>
              </div>
              <div className="mt-2 text-2xl font-extrabold text-slate-900 font-mono-num">
                {overview.analytics.deliveredCount} / {overview.analytics.totalOrders}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-8 rounded-2xl border border-slate-200 bg-white p-5 space-y-4">
              <h3 className="font-bold text-sm text-slate-900">
                أداء إيرادات التوصيل حسب المنطقة (د.ع)
              </h3>
              <div className="h-72 w-full" dir="ltr">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={overview.analytics.zonePerformance}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                    <XAxis dataKey="name" tick={{ fontSize: 11, fill: '#334155' }} />
                    <YAxis tick={{ fontSize: 11, fill: '#334155' }} />
                    <Tooltip
                      formatter={(val: unknown) => [formatIqd(Number(val) || 0), 'الأجور']}
                    />
                    <Bar dataKey="revenueIqd" fill="#0284C7" radius={[8, 8, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="lg:col-span-4 rounded-2xl border border-slate-200 bg-white p-5 space-y-3">
              <h3 className="font-bold text-sm text-slate-900">ملخص حالات الطلبات</h3>
              <div className="divide-y divide-slate-100 text-sm">
                {(Object.keys(ORDER_STATUS_META) as OrderStatus[]).map((st) => (
                  <div key={st} className="py-2.5 flex items-center justify-between">
                    <span className="text-slate-700">{ORDER_STATUS_META[st].label}</span>
                    <span className="font-mono-num font-bold text-slate-900">
                      {overview.analytics.statusCounts[st] || 0}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: DELIVERY ZONES + ZONE-TO-ZONE ROUTE MATRIX */}
      {overview && adminTab === 'zones' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* Add / Edit Zone Form */}
            <form
              onSubmit={handleSaveZone}
              className="lg:col-span-5 rounded-2xl border border-slate-200 bg-white p-5 space-y-4"
            >
              <div className="flex items-center justify-between">
                <h3 className="text-base font-extrabold text-slate-900 flex items-center gap-2">
                  <Plus className="w-5 h-5 text-sky-600" />
                  <span>{editingZoneId ? 'تعديل منطقة وأجرتها' : 'إضافة منطقة أو حي جديد'}</span>
                </h3>
                {editingZoneId && (
                  <button
                    type="button"
                    onClick={resetZoneForm}
                    className="text-xs font-semibold text-sky-700 underline cursor-pointer"
                  >
                    إلغاء التعديل
                  </button>
                )}
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    اسم المنطقة / الحي
                  </label>
                  <input
                    type="text"
                    required
                    value={zoneName}
                    onChange={(e) => setZoneName(e.target.value)}
                    placeholder="مثال: الغزالية"
                    className="w-full min-h-[42px] rounded-xl border border-slate-200 px-3 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">المدينة</label>
                  <input
                    type="text"
                    required
                    value={zoneCity}
                    onChange={(e) => setZoneCity(e.target.value)}
                    placeholder="بغداد"
                    className="w-full min-h-[42px] rounded-xl border border-slate-200 px-3 text-sm"
                  />
                </div>
              </div>

              <GoogleMapsView
                apiKey={mapsApiKey}
                mode="picker"
                center={{ lat: zoneLat, lng: zoneLng }}
                delivery={{ lat: zoneLat, lng: zoneLng, label: zoneName || 'مركز المنطقة' }}
                zones={overview.zones}
                onLocationPicked={(lat, lng) => {
                  setZoneLat(lat);
                  setZoneLng(lng);
                }}
                heightClass="h-44"
              />

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    نصف قطر التغطية (كم)
                  </label>
                  <input
                    type="number"
                    min={0.5}
                    max={200}
                    step={0.5}
                    value={zoneRadiusKm}
                    onChange={(e) => setZoneRadiusKm(Number(e.target.value))}
                    className="w-full min-h-[42px] rounded-xl border border-slate-200 px-3 text-sm font-mono-num"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    نظام التسعير داخل المنطقة
                  </label>
                  <select
                    value={zonePricingMode}
                    onChange={(e) => setZonePricingMode(e.target.value as ZonePricingMode)}
                    className="w-full min-h-[42px] rounded-xl border border-slate-200 px-3 text-sm bg-white"
                  >
                    <option value="fixed">أجرة ثابتة للمنطقة</option>
                    <option value="distance">حسب المسافة (أساسي + كم)</option>
                  </select>
                </div>
              </div>

              {zonePricingMode === 'fixed' ? (
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    أجرة التوصيل الثابتة داخل المنطقة (د.ع)
                  </label>
                  <input
                    type="number"
                    min={0}
                    step={250}
                    value={zoneFixedFee}
                    onChange={(e) => setZoneFixedFee(Number(e.target.value))}
                    className="w-full min-h-[42px] rounded-xl border border-slate-200 px-3 text-sm font-mono-num"
                  />
                </div>
              ) : (
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      الأجرة الأساسية (د.ع)
                    </label>
                    <input
                      type="number"
                      min={0}
                      step={250}
                      value={zoneBaseFee}
                      onChange={(e) => setZoneBaseFee(Number(e.target.value))}
                      className="w-full min-h-[42px] rounded-xl border border-slate-200 px-3 text-sm font-mono-num"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      أجرة كل كيلومتر (د.ع)
                    </label>
                    <input
                      type="number"
                      min={0}
                      step={250}
                      value={zonePerKmFee}
                      onChange={(e) => setZonePerKmFee(Number(e.target.value))}
                      className="w-full min-h-[42px] rounded-xl border border-slate-200 px-3 text-sm font-mono-num"
                    />
                  </div>
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  ملاحظات المنطقة (اختياري)
                </label>
                <input
                  type="text"
                  value={zoneNotes}
                  onChange={(e) => setZoneNotes(e.target.value)}
                  placeholder="الأحياء المشمولة أو تفاصيل إضافية"
                  className="w-full min-h-[42px] rounded-xl border border-slate-200 px-3 text-sm"
                />
              </div>

              <div className="flex flex-wrap gap-4 text-xs text-slate-700">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={zoneIsCovered}
                    onChange={(e) => setZoneIsCovered(e.target.checked)}
                    className="w-4 h-4 rounded text-sky-600"
                  />
                  <span>التغطية مفتوحة للطلبات</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={zoneIsActive}
                    onChange={(e) => setZoneIsActive(e.target.checked)}
                    className="w-4 h-4 rounded text-sky-600"
                  />
                  <span>تفعيل وظهور المنطقة</span>
                </label>
              </div>

              <button
                type="submit"
                disabled={savingZone}
                className="w-full min-h-[44px] rounded-xl bg-sky-600 text-white font-bold text-sm hover:bg-sky-700 cursor-pointer disabled:opacity-50"
              >
                {savingZone
                  ? 'جاري الحفظ...'
                  : editingZoneId
                  ? 'حفظ تعديلات المنطقة وتحديث الأسعار فوراً'
                  : 'إضافة المنطقة وتفعيلها فوراً'}
              </button>
            </form>

            {/* Existing Zones List */}
            <div className="lg:col-span-7 rounded-2xl border border-slate-200 bg-white divide-y divide-slate-100">
              <div className="px-5 py-3.5 flex items-center justify-between">
                <h3 className="font-bold text-sm text-slate-900">
                  المناطق والأحياء المسجلة ({overview.zones.length})
                </h3>
                <span className="text-xs text-slate-500">تحكم فوري بالاسم والأجرة والتغطية</span>
              </div>

              {overview.zones.map((z) => (
                <div
                  key={z.id}
                  className="p-4 flex flex-wrap items-center justify-between gap-3 text-sm"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-extrabold text-slate-900">{z.name}</span>
                      <span className="text-xs text-slate-500">({z.city})</span>
                      <span
                        className={`text-[11px] font-semibold px-2 py-0.5 rounded-md border ${
                          z.isCovered
                            ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                            : 'bg-rose-50 text-rose-700 border-rose-200'
                        }`}
                      >
                        {z.isCovered ? 'تغطية فعالة' : 'تغطية متوقفة'}
                      </span>
                    </div>
                    <div className="text-xs text-slate-600 font-mono-num">
                      نطاق {z.radiusKm} كم ·{' '}
                      {z.pricingMode === 'fixed'
                        ? `أجرة ثابتة: ${formatIqd(z.fixedFeeIqd)}`
                        : `أساسي ${formatIqd(z.baseFeeIqd)} + ${formatIqd(z.perKmFeeIqd)}/كم`}
                    </div>
                    {z.notes && <div className="text-xs text-slate-400">{z.notes}</div>}
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => void handleToggleZoneCoverage(z)}
                      className={`min-h-[34px] px-3 rounded-lg text-xs font-semibold border cursor-pointer ${
                        z.isCovered
                          ? 'border-amber-200 bg-amber-50 text-amber-800 hover:bg-amber-100'
                          : 'border-emerald-200 bg-emerald-50 text-emerald-800 hover:bg-emerald-100'
                      }`}
                    >
                      {z.isCovered ? 'إيقاف التغطية' : 'تفعيل التغطية'}
                    </button>
                    <button
                      type="button"
                      onClick={() => startEditZone(z)}
                      className="w-9 h-9 rounded-lg border border-sky-200 bg-sky-50 text-sky-700 flex items-center justify-center hover:bg-sky-100 cursor-pointer"
                      aria-label="تعديل المنطقة"
                    >
                      <Edit3 className="w-4 h-4" />
                    </button>
                    <button
                      type="button"
                      onClick={() => void handleDeleteZone(z)}
                      className="w-9 h-9 rounded-lg border border-rose-200 bg-rose-50 text-rose-700 flex items-center justify-center hover:bg-rose-100 cursor-pointer"
                      aria-label="حذف المنطقة"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Zone-to-Zone Pricing Matrix */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            <form
              onSubmit={handleSaveRouteRate}
              className="lg:col-span-5 rounded-2xl border border-slate-200 bg-white p-5 space-y-4"
            >
              <h3 className="text-base font-extrabold text-slate-900 flex items-center gap-2">
                <ArrowLeftRight className="w-5 h-5 text-sky-600" />
                <span>تحديد أجرة الانتقال بين منطقتين</span>
              </h3>
              <p className="text-xs text-slate-500">
                حدّد سعراً مخصصاً عند انتقال الطلب من منطقة إلى منطقة أخرى (مثال: المنصور ↔ الكرادة).
              </p>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    من منطقة (الاستلام)
                  </label>
                  <select
                    value={routeFromZoneId}
                    onChange={(e) => setRouteFromZoneId(e.target.value)}
                    className="w-full min-h-[42px] rounded-xl border border-slate-200 px-3 text-sm bg-white"
                  >
                    {overview.zones.map((z) => (
                      <option key={z.id} value={z.id}>
                        {z.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    إلى منطقة (التسليم)
                  </label>
                  <select
                    value={routeToZoneId}
                    onChange={(e) => setRouteToZoneId(e.target.value)}
                    className="w-full min-h-[42px] rounded-xl border border-slate-200 px-3 text-sm bg-white"
                  >
                    {overview.zones.map((z) => (
                      <option key={z.id} value={z.id}>
                        {z.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    الأجرة بين المنطقتين (د.ع)
                  </label>
                  <input
                    type="number"
                    min={0}
                    step={250}
                    value={routeFeeIqd}
                    onChange={(e) => setRouteFeeIqd(Number(e.target.value))}
                    className="w-full min-h-[42px] rounded-xl border border-slate-200 px-3 text-sm font-mono-num"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    ملاحظة (اختياري)
                  </label>
                  <input
                    type="text"
                    value={routeNotes}
                    onChange={(e) => setRouteNotes(e.target.value)}
                    placeholder="مثال: عبور جسر أو مسار مباشر"
                    className="w-full min-h-[42px] rounded-xl border border-slate-200 px-3 text-sm"
                  />
                </div>
              </div>

              <label className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer">
                <input
                  type="checkbox"
                  checked={routeBidirectional}
                  onChange={(e) => setRouteBidirectional(e.target.checked)}
                  className="w-4 h-4 rounded text-sky-600"
                />
                <span>تطبيق نفس السعر بالاتجاهين (ذهاباً وإياباً)</span>
              </label>

              <button
                type="submit"
                disabled={savingRoute || overview.zones.length < 2}
                className="w-full min-h-[44px] rounded-xl bg-slate-900 text-white font-bold text-sm hover:bg-slate-800 cursor-pointer disabled:opacity-50"
              >
                {savingRoute ? 'جاري الحفظ...' : 'حفظ أجرة الانتقال بين المنطقتين'}
              </button>
            </form>

            <div className="lg:col-span-7 rounded-2xl border border-slate-200 bg-white divide-y divide-slate-100">
              <div className="px-5 py-3.5 flex items-center justify-between">
                <h3 className="font-bold text-sm text-slate-900">
                  جدول أجور الانتقال بين المناطق ({overview.routeRates.length})
                </h3>
                <span className="text-xs text-slate-500">يُطبَّق فوراً عند إنشاء أي طلب</span>
              </div>

              {overview.routeRates.length === 0 ? (
                <div className="p-6 text-center text-sm text-slate-500">
                  لم تضف قواعد انتقال مخصصة بعد. يتم احتساب رسوم الانتقال الافتراضية تلقائياً.
                </div>
              ) : (
                overview.routeRates.map((r) => (
                  <div
                    key={r.id}
                    className="p-4 flex flex-wrap items-center justify-between gap-3 text-sm"
                  >
                    <div className="space-y-0.5">
                      <div className="font-bold text-slate-900 flex items-center gap-2">
                        <span>{r.fromZoneName}</span>
                        <span className="text-sky-600">{r.bidirectional ? '↔' : '←'}</span>
                        <span>{r.toZoneName}</span>
                        <span
                          className={`text-[11px] font-semibold px-2 py-0.5 rounded-md border ${
                            r.isActive
                              ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                              : 'bg-slate-100 text-slate-500 border-slate-200'
                          }`}
                        >
                          {r.isActive ? 'فعال' : 'معطل'}
                        </span>
                      </div>
                      <div className="text-xs text-slate-600 font-mono-num">
                        الأجرة المحددة: <strong className="text-sky-700">{formatIqd(r.feeIqd)}</strong>
                        {r.notes ? ` · ${r.notes}` : ''}
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => void handleToggleRouteActive(r)}
                        className="min-h-[34px] px-3 rounded-lg border border-slate-200 bg-slate-50 text-xs font-semibold text-slate-700 hover:bg-slate-100 cursor-pointer"
                      >
                        {r.isActive ? 'إيقاف' : 'تفعيل'}
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setRouteFromZoneId(r.fromZoneId);
                          setRouteToZoneId(r.toZoneId);
                          setRouteFeeIqd(r.feeIqd);
                          setRouteBidirectional(r.bidirectional);
                          setRouteNotes(r.notes || '');
                        }}
                        className="w-9 h-9 rounded-lg border border-sky-200 bg-sky-50 text-sky-700 flex items-center justify-center hover:bg-sky-100 cursor-pointer"
                        aria-label="تعديل السعر"
                      >
                        <Edit3 className="w-4 h-4" />
                      </button>
                      <button
                        type="button"
                        onClick={() => void handleDeleteRoute(r)}
                        className="w-9 h-9 rounded-lg border border-rose-200 bg-rose-50 text-rose-700 flex items-center justify-center hover:bg-rose-100 cursor-pointer"
                        aria-label="حذف المسار"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: FREELANCE COURIER ORDERS & DISPATCH */}
      {overview && adminTab === 'orders' && (
        <div className="rounded-2xl border border-slate-200 bg-white overflow-hidden">
          <div className="px-5 py-3.5 border-b border-slate-100 font-bold text-sm text-slate-900">
            جميع طلبات التوصيل ({overview.orders.length})
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-right text-xs sm:text-sm">
              <thead className="bg-slate-50 text-slate-600 border-b border-slate-200">
                <tr>
                  <th className="py-3 px-4 font-semibold">الرمز والغرض</th>
                  <th className="py-3 px-4 font-semibold">المرسل والمستلم</th>
                  <th className="py-3 px-4 font-semibold">المسار والمنطقة</th>
                  <th className="py-3 px-4 font-semibold">أجرة التوصيل</th>
                  <th className="py-3 px-4 font-semibold">توزيع (25% / 75%)</th>
                  <th className="py-3 px-4 font-semibold">تعيين مندوب</th>
                  <th className="py-3 px-4 font-semibold">الحالة</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {overview.orders.map((ord) => (
                  <tr key={ord.id} className="hover:bg-slate-50/60">
                    <td className="py-3 px-4">
                      <div className="font-mono-num font-bold text-slate-900">{ord.trackingCode}</div>
                      <div className="font-semibold text-sky-800 mt-0.5">{ord.itemName}</div>
                      <div className="text-[11px] text-slate-500">
                        {SENDER_TYPE_LABELS[ord.senderType]}
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-semibold text-slate-900">
                        من: {ord.senderName}{' '}
                        <span className="text-xs font-mono-num text-slate-500">
                          ({ord.senderPhone})
                        </span>
                      </div>
                      <div className="text-xs text-slate-600 mt-0.5">
                        إلى: {ord.recipientName || 'مستلم'}{' '}
                        <span className="font-mono-num text-slate-500">({ord.recipientPhone})</span>
                      </div>
                    </td>
                    <td className="py-3 px-4 text-slate-700 text-xs">
                      <div>
                        {ord.pickupAddress} ← {ord.deliveryAddress}
                      </div>
                      <div className="text-sky-700 mt-0.5">
                        {ord.zoneName || 'توصيل عام'} ·{' '}
                        <span className="font-mono-num">{ord.distanceKm} كم</span>
                      </div>
                    </td>
                    <td className="py-3 px-4 font-mono-num text-sky-700 font-bold">
                      {formatIqd(ord.deliveryFeeIqd)}
                    </td>
                    <td className="py-3 px-4 font-mono-num text-xs">
                      <div className="text-emerald-700 font-semibold">
                        وصلها: {formatIqd(ord.platformFeeIqd)}
                      </div>
                      <div className="text-slate-600">مندوب: {formatIqd(ord.driverNetIqd)}</div>
                    </td>
                    <td className="py-3 px-4">
                      <select
                        value={ord.driverId || ''}
                        onChange={(e) => {
                          if (e.target.value) {
                            void handleAdminOrderUpdate(ord.id, { driverId: e.target.value });
                          }
                        }}
                        className="min-h-[36px] rounded-lg border border-slate-200 bg-white px-2 text-xs"
                      >
                        <option value="">بدون مندوب</option>
                        {overview.drivers
                          .filter((d) => d.status === 'active')
                          .map((d) => (
                            <option key={d.id} value={d.id}>
                              {d.name}
                            </option>
                          ))}
                      </select>
                    </td>
                    <td className="py-3 px-4">
                      <select
                        value={ord.status}
                        onChange={(e) =>
                          void handleAdminOrderUpdate(ord.id, {
                            status: e.target.value as OrderStatus,
                          })
                        }
                        className="min-h-[36px] rounded-lg border border-slate-200 bg-white px-2 text-xs"
                      >
                        {(Object.keys(ORDER_STATUS_META) as OrderStatus[]).map((st) => (
                          <option key={st} value={st}>
                            {ORDER_STATUS_META[st].label}
                          </option>
                        ))}
                      </select>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 4: DRIVERS & CUSTOMERS/SHOPS */}
      {overview && adminTab === 'users' && (
        <div className="space-y-6">
          <div className="rounded-2xl border border-slate-200 bg-white overflow-hidden">
            <div className="px-5 py-3.5 border-b border-slate-100 font-bold text-sm text-slate-900">
              المندوبون وأرباحهم ({overview.drivers.length})
            </div>
            <div className="divide-y divide-slate-100">
              {overview.drivers.map((drv) => (
                <div
                  key={drv.id}
                  className="p-4 flex flex-wrap items-center justify-between gap-4 text-sm"
                >
                  <div>
                    <div className="font-bold text-slate-900">
                      {drv.name} ·{' '}
                      <span className="text-xs font-normal text-slate-500">
                        {VEHICLE_TYPE_LABELS[drv.vehicleType]} ({drv.plateNumber})
                      </span>
                    </div>
                    <div className="text-xs text-slate-500 font-mono-num mt-0.5">
                      {drv.phone} · توصيلات مكتملة: {drv.completedCount} · الأرباح:{' '}
                      {formatIqd(drv.earningsIqd)}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span
                      className={`text-xs font-semibold px-2.5 py-1 rounded-md border ${
                        drv.status === 'active'
                          ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                          : 'bg-rose-50 text-rose-700 border-rose-200'
                      }`}
                    >
                      {drv.status === 'active' ? 'حساب نشط' : 'موقوف'}
                    </span>
                    <button
                      type="button"
                      onClick={() =>
                        void handleToggleUserStatus(
                          drv.ownerId,
                          drv.status === 'active' ? 'suspended' : 'active'
                        )
                      }
                      className="min-h-[36px] px-3 rounded-lg border border-slate-200 bg-slate-50 text-xs font-semibold text-slate-700 hover:bg-slate-100 cursor-pointer"
                    >
                      {drv.status === 'active' ? 'إيقاف الحساب' : 'تفعيل الحساب'}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="rounded-2xl border border-slate-200 bg-white overflow-hidden">
            <div className="px-5 py-3.5 border-b border-slate-100 font-bold text-sm text-slate-900">
              حسابات الزبائن وأصحاب المحلات والمستخدمين ({overview.users.length})
            </div>
            <div className="divide-y divide-slate-100">
              {overview.users.map((u) => (
                <div
                  key={u.id}
                  className="p-4 flex flex-wrap items-center justify-between gap-4 text-sm"
                >
                  <div>
                    <div className="font-bold text-slate-900">{u.name}</div>
                    <div className="text-xs text-slate-500 mt-0.5">
                      <span className="font-mono-num">{u.phone}</span> · الدور: {u.role}
                    </div>
                  </div>
                  {u.role !== 'super_admin' && (
                    <button
                      type="button"
                      onClick={() =>
                        void handleToggleUserStatus(
                          u.id,
                          u.status === 'active' ? 'suspended' : 'active'
                        )
                      }
                      className={`min-h-[36px] px-3.5 rounded-lg text-xs font-semibold border cursor-pointer ${
                        u.status === 'active'
                          ? 'bg-rose-50 text-rose-700 border-rose-200 hover:bg-rose-100'
                          : 'bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100'
                      }`}
                    >
                      {u.status === 'active' ? 'إيقاف الحساب' : 'تفعيل الحساب'}
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 5: GLOBAL PRICING, LONG DISTANCE, BACKUPS & 3 ANDROID APPS */}
      {overview && adminTab === 'pricing' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            <form
              onSubmit={handleSavePricing}
              className="lg:col-span-7 rounded-2xl border border-slate-200 bg-white p-6 space-y-4"
            >
              <h3 className="text-base font-extrabold text-slate-900">
                قواعد أجور المسافات البعيدة والانتقال والعمولة (تُعمم فوراً)
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    أجرة التوصيل الأساسية الافتراضية (د.ع)
                  </label>
                  <input
                    type="number"
                    min={0}
                    max={500000}
                    step={250}
                    value={baseFeeIqd}
                    onChange={(e) => setBaseFeeIqd(Number(e.target.value))}
                    className="w-full min-h-[44px] rounded-xl border border-slate-200 px-3 text-sm font-mono-num"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    سعر الكيلومتر الافتراضي (د.ع)
                  </label>
                  <input
                    type="number"
                    min={0}
                    max={50000}
                    step={250}
                    value={perKmFeeIqd}
                    onChange={(e) => setPerKmFeeIqd(Number(e.target.value))}
                    className="w-full min-h-[44px] rounded-xl border border-slate-200 px-3 text-sm font-mono-num"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    رسوم الانتقال الافتراضية بين منطقتين (د.ع)
                  </label>
                  <input
                    type="number"
                    min={0}
                    max={250000}
                    step={250}
                    value={interZoneFeeIqd}
                    onChange={(e) => setInterZoneFeeIqd(Number(e.target.value))}
                    className="w-full min-h-[44px] rounded-xl border border-slate-200 px-3 text-sm font-mono-num"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    أجرة إضافية خارج المناطق المغطاة (د.ع)
                  </label>
                  <input
                    type="number"
                    min={0}
                    max={250000}
                    step={250}
                    value={outsideZoneSurchargeIqd}
                    onChange={(e) => setOutsideZoneSurchargeIqd(Number(e.target.value))}
                    className="w-full min-h-[44px] rounded-xl border border-slate-200 px-3 text-sm font-mono-num"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1 border-t border-slate-100">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    بداية المسافة البعيدة (كم)
                  </label>
                  <input
                    type="number"
                    min={0}
                    max={200}
                    step={0.5}
                    value={longDistanceThresholdKm}
                    onChange={(e) => setLongDistanceThresholdKm(Number(e.target.value))}
                    className="w-full min-h-[44px] rounded-xl border border-slate-200 px-3 text-sm font-mono-num"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    أجرة كل كيلومتر إضافي للمسافات البعيدة (د.ع)
                  </label>
                  <input
                    type="number"
                    min={0}
                    max={50000}
                    step={250}
                    value={longDistancePerKmFeeIqd}
                    onChange={(e) => setLongDistancePerKmFeeIqd(Number(e.target.value))}
                    className="w-full min-h-[44px] rounded-xl border border-slate-200 px-3 text-sm font-mono-num"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-1 border-t border-slate-100">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    الحد الأدنى للأجرة (د.ع)
                  </label>
                  <input
                    type="number"
                    min={0}
                    max={500000}
                    step={250}
                    value={minFeeIqd}
                    onChange={(e) => setMinFeeIqd(Number(e.target.value))}
                    className="w-full min-h-[44px] rounded-xl border border-slate-200 px-3 text-sm font-mono-num"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    الحد الأقصى للأجرة (د.ع)
                  </label>
                  <input
                    type="number"
                    min={0}
                    max={500000}
                    step={250}
                    value={maxFeeIqd}
                    onChange={(e) => setMaxFeeIqd(Number(e.target.value))}
                    className="w-full min-h-[44px] rounded-xl border border-slate-200 px-3 text-sm font-mono-num"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    نسبة عمولة وصلها (%)
                  </label>
                  <input
                    type="number"
                    min={0}
                    max={50}
                    step={1}
                    value={platformCommissionPct}
                    onChange={(e) => setPlatformCommissionPct(Number(e.target.value))}
                    className="w-full min-h-[44px] rounded-xl border border-slate-200 px-3 text-sm font-mono-num"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    اسم المنصة
                  </label>
                  <input
                    type="text"
                    value={appName}
                    onChange={(e) => setAppName(e.target.value)}
                    className="w-full min-h-[44px] rounded-xl border border-slate-200 px-3 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    هاتف الدعم الفني
                  </label>
                  <input
                    type="tel"
                    dir="ltr"
                    value={supportPhone}
                    onChange={(e) => setSupportPhone(e.target.value)}
                    className="w-full min-h-[44px] rounded-xl border border-slate-200 px-3 text-sm text-left font-mono-num"
                  />
                </div>
              </div>

              <div className="space-y-2 pt-1">
                <label className="flex items-center gap-2.5 text-sm text-slate-700 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={outsideZonesAllowed}
                    onChange={(e) => setOutsideZonesAllowed(e.target.checked)}
                    className="w-4 h-4 rounded border-slate-300 text-sky-600"
                  />
                  <span>السماح باستقبال الطلبات خارج نطاق المناطق المحددة</span>
                </label>

                <label className="flex items-center gap-2.5 text-sm text-slate-700 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={maintenanceMode}
                    onChange={(e) => setMaintenanceMode(e.target.checked)}
                    className="w-4 h-4 rounded border-slate-300 text-sky-600"
                  />
                  <span>تفعيل وضع الصيانة المؤقت (إيقاف استقبال طلبات جديدة مؤقتاً)</span>
                </label>
              </div>

              <button
                type="submit"
                disabled={savingPricing}
                className="min-h-[46px] px-6 rounded-xl bg-sky-600 text-white font-bold text-sm hover:bg-sky-700 cursor-pointer disabled:opacity-50"
              >
                {savingPricing ? 'جاري الحفظ...' : 'حفظ وتعميم التسعيرة فوراً'}
              </button>
            </form>

            {/* 3 Android Apps Deployment Card */}
            <div className="lg:col-span-5 rounded-2xl border border-slate-200 bg-white p-6 space-y-4">
              <h3 className="text-base font-extrabold text-slate-900 flex items-center gap-2">
                <Smartphone className="w-5 h-5 text-sky-600" />
                <span>تطبيقات Android الثلاثة المستقلة</span>
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                كل تطبيق يملك رابطاً مستقلاً وملف Manifest مخصصاً للتثبيت المباشر على هواتف Android،
                مع حزم بناء مستقلة (Capacitor) بدون أي بيانات سرية للمدير داخل تطبيق الزبائن أو المندوبين:
              </p>
              <div className="space-y-2 text-xs">
                <a
                  href="/customer"
                  className="flex items-center justify-between rounded-xl border border-slate-200 p-3 hover:border-sky-400"
                >
                  <span className="font-bold text-slate-900">
                    1. وصلها للزبائن والمحلات (WASELHA CUSTOMER)
                  </span>
                  <span className="font-mono-num text-sky-700">/customer</span>
                </a>
                <a
                  href="/driver"
                  className="flex items-center justify-between rounded-xl border border-slate-200 p-3 hover:border-sky-400"
                >
                  <span className="font-bold text-slate-900">2. وصلها للمندوبين (WASELHA DRIVER)</span>
                  <span className="font-mono-num text-sky-700">/driver</span>
                </a>
                <a
                  href="/manager"
                  className="flex items-center justify-between rounded-xl border border-slate-200 p-3 hover:border-sky-400"
                >
                  <span className="font-bold text-slate-900">3. وصلها للإدارة (WASELHA MANAGER)</span>
                  <span className="font-mono-num text-sky-700">/manager</span>
                </a>
              </div>
              <div className="rounded-xl bg-slate-50 border border-slate-200 p-3.5 text-xs text-slate-700 space-y-1.5">
                <div className="font-bold text-slate-900">
                  بناء حزم الويب المستقلة للتطبيقات الثلاثة وتوقيع APK:
                </div>
                <p
                  className="font-mono-num text-[11px] bg-white p-2 rounded-lg border border-slate-200 text-left"
                  dir="ltr"
                >
                  npm run build:all-apps
                </p>
                <p className="text-slate-500">
                  ثم تغليف كل مجلد (<code>dist-customer</code>, <code>dist-driver</code>,{' '}
                  <code>dist-manager</code>) عبر <code>mobile/build-apks.sh</code> مع Java 17 و
                  Android SDK.
                </p>
              </div>
            </div>
          </div>

          {/* Database Backups & Restore Section */}
          <div className="rounded-2xl border border-slate-200 bg-white p-6 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div>
                <h3 className="text-base font-extrabold text-slate-900 flex items-center gap-2">
                  <DatabaseBackup className="w-5 h-5 text-sky-600" />
                  <span>النسخ الاحتياطي واستعادة قاعدة البيانات</span>
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  يتم حفظ نسخ احتياطية تلقائياً، ويمكنك أخذ نسخة فورية أو تنزيلها أو استعادتها.
                </p>
              </div>
              <button
                type="button"
                disabled={backupBusy}
                onClick={handleCreateBackup}
                className="min-h-[42px] inline-flex items-center gap-2 rounded-xl bg-slate-900 text-white px-4 text-xs font-bold hover:bg-slate-800 cursor-pointer disabled:opacity-50"
              >
                <DatabaseBackup className="w-4 h-4" />
                <span>{backupBusy ? 'جاري التنفيذ...' : 'إنشاء نسخة احتياطية الآن'}</span>
              </button>
            </div>

            <div className="divide-y divide-slate-100 border border-slate-200 rounded-xl overflow-hidden">
              {overview.backups.length === 0 ? (
                <div className="p-6 text-center text-xs text-slate-500">
                  لا توجد نسخ احتياطية محفوظة بعد.
                </div>
              ) : (
                overview.backups.map((bk) => (
                  <div
                    key={bk.filename}
                    className="p-3.5 flex flex-wrap items-center justify-between gap-3 text-xs"
                  >
                    <div>
                      <div className="font-mono-num font-bold text-slate-900">{bk.filename}</div>
                      <div className="text-slate-500 mt-0.5">
                        {new Date(bk.createdAt).toLocaleString('ar-IQ')} · الطلبات: {bk.ordersCount}{' '}
                        · المناطق: {bk.zonesCount} · {(bk.sizeBytes / 1024).toFixed(1)} KB
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <a
                        href={resolveApiUrl(`/api/admin/backups/${bk.filename}`)}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="min-h-[34px] inline-flex items-center gap-1.5 px-3 rounded-lg border border-slate-200 bg-slate-50 text-slate-700 font-semibold hover:bg-slate-100"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>تنزيل</span>
                      </a>
                      <button
                        type="button"
                        disabled={backupBusy}
                        onClick={() => void handleRestoreBackup(bk.filename)}
                        className="min-h-[34px] inline-flex items-center gap-1.5 px-3 rounded-lg border border-amber-200 bg-amber-50 text-amber-800 font-semibold hover:bg-amber-100 cursor-pointer"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                        <span>استعادة</span>
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
