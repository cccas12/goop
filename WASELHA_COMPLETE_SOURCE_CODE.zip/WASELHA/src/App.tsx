import { useCallback, useEffect, useState } from 'react';
import { onAuthStateChanged } from 'firebase/auth';
import {
  ArrowRight,
  CheckCircle2,
  Download,
  MapPin,
  Package,
  ShieldCheck,
  Smartphone,
  Truck,
  Wrench,
  X,
} from 'lucide-react';
import { auth } from './firebase';
import { apiRequest, resolveApiUrl } from './services/api';
import {
  formatIqd,
  type AppMode,
  type DeliveryZone,
  type Driver,
  type PricingSettings,
  type UserAccount,
  type ZoneRouteRate,
} from './types';
import { SplashScreen, WASELHA_LOGO_URL } from './components/SplashScreen';
import { OfflineIndicator, PWAInstallButton } from './hooks/usePWAInstall';
import { CustomerSection } from './components/CustomerSection';
import { DriverSection } from './components/DriverSection';
import { AdminSection } from './components/AdminSection';

interface BootstrapResponse {
  zones: DeliveryZone[];
  routeRates: ZoneRouteRate[];
  settings: PricingSettings;
}

interface AuthMeResponse {
  user: UserAccount | null;
  driver?: Driver;
}

const DEFAULT_SETTINGS: PricingSettings = {
  baseFeeIqd: 0,
  perKmFeeIqd: 0,
  minFeeIqd: 0,
  maxFeeIqd: 0,
  interZoneFeeIqd: 0,
  longDistanceThresholdKm: 0,
  longDistancePerKmFeeIqd: 0,
  platformCommissionPct: 25,
  outsideZonesAllowed: true,
  outsideZoneSurchargeIqd: 0,
  appName: 'وصلها - WASELHA',
  supportPhone: '',
  maintenanceMode: false,
  updatedAt: '',
};

const ENV_APP_MODE = (import.meta.env.VITE_APP_MODE || '').trim() as AppMode | '';
const IS_LOCKED_APK_BUILD =
  ENV_APP_MODE === 'customer' || ENV_APP_MODE === 'driver' || ENV_APP_MODE === 'manager';

function resolvePathToMode(pathname: string): AppMode {
  if (IS_LOCKED_APK_BUILD && ENV_APP_MODE) {
    return ENV_APP_MODE;
  }
  const p = pathname.toLowerCase();
  if (p.startsWith('/customer')) return 'customer';
  if (p.startsWith('/driver')) return 'driver';
  if (p.startsWith('/manager')) return 'manager';
  return 'hub';
}

const APP_MODE_META: Record<
  AppMode,
  {
    titleAr: string;
    subtitleEn: string;
    manifestHref: string;
    documentTitle: string;
    path: string;
    packageId?: string;
  }
> = {
  hub: {
    titleAr: 'منظومة وصلها',
    subtitleEn: 'WASELHA COURIER SUITE',
    manifestHref: '/manifest.webmanifest',
    documentTitle: 'وصلها - WASELHA | منصة التوصيل الحر السريع',
    path: '/',
  },
  customer: {
    titleAr: 'وصلها للزبائن والمحلات',
    subtitleEn: 'WASELHA CUSTOMER',
    manifestHref: '/manifest-customer.json',
    documentTitle: 'وصلها للزبائن والمحلات - WASELHA CUSTOMER',
    path: '/customer',
    packageId: 'iq.waselha.customer',
  },
  driver: {
    titleAr: 'وصلها للمندوبين',
    subtitleEn: 'WASELHA DRIVER',
    manifestHref: '/manifest-driver.json',
    documentTitle: 'وصلها للمندوبين - WASELHA DRIVER',
    path: '/driver',
    packageId: 'iq.waselha.driver',
  },
  manager: {
    titleAr: 'وصلها للإدارة',
    subtitleEn: 'WASELHA MANAGER',
    manifestHref: '/manifest-manager.json',
    documentTitle: 'وصلها للإدارة - WASELHA MANAGER',
    path: '/manager',
    packageId: 'iq.waselha.manager',
  },
};

export default function App() {
  const [appMode, setAppMode] = useState<AppMode>(() =>
    resolvePathToMode(typeof window !== 'undefined' ? window.location.pathname : '/')
  );
  const [showSplash, setShowSplash] = useState(true);
  const [zones, setZones] = useState<DeliveryZone[]>([]);
  const [routeRates, setRouteRates] = useState<ZoneRouteRate[]>([]);
  const [settings, setSettings] = useState<PricingSettings>(DEFAULT_SETTINGS);
  const [mapsApiKey, setMapsApiKey] = useState<string>(
    import.meta.env.VITE_GOOGLE_MAPS_API_KEY || ''
  );

  const [currentUser, setCurrentUser] = useState<UserAccount | null>(null);
  const [currentDriver, setCurrentDriver] = useState<Driver | null>(null);
  const [firebaseEmail, setFirebaseEmail] = useState<string | null>(null);

  const [bootLoading, setBootLoading] = useState(true);
  const [bootError, setBootError] = useState<string | null>(null);
  const [realtimeTick, setRealtimeTick] = useState(0);
  const [mapsQuotaExceeded, setMapsQuotaExceeded] = useState(false);
  const [showAndroidModal, setShowAndroidModal] = useState(false);

  const navigateToMode = useCallback((nextMode: AppMode) => {
    if (IS_LOCKED_APK_BUILD) return;
    const targetPath = APP_MODE_META[nextMode].path;
    if (typeof window !== 'undefined' && window.location.pathname !== targetPath) {
      window.history.pushState({}, '', targetPath);
    }
    setAppMode(nextMode);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  useEffect(() => {
    if (IS_LOCKED_APK_BUILD) return;
    const onPopState = () => {
      setAppMode(resolvePathToMode(window.location.pathname));
    };
    window.addEventListener('popstate', onPopState);
    return () => window.removeEventListener('popstate', onPopState);
  }, []);

  useEffect(() => {
    const meta = APP_MODE_META[appMode];
    document.title = meta.documentTitle;
    const existing = document.querySelector<HTMLLinkElement>('link[rel="manifest"]');
    if (existing) {
      existing.href = meta.manifestHref;
    } else {
      const link = document.createElement('link');
      link.rel = 'manifest';
      link.href = meta.manifestHref;
      document.head.appendChild(link);
    }
  }, [appMode]);

  const fetchBootstrap = useCallback(async (attempt = 0) => {
    try {
      const [bootData, configData] = await Promise.all([
        apiRequest<BootstrapResponse>('/api/bootstrap'),
        apiRequest<{ googleMapsApiKey?: string }>('/api/config/public'),
      ]);
      setZones(bootData.zones || []);
      setRouteRates(bootData.routeRates || []);
      setSettings(bootData.settings || DEFAULT_SETTINGS);
      if (configData.googleMapsApiKey) {
        setMapsApiKey(configData.googleMapsApiKey);
      }
      setBootError(null);
      setBootLoading(false);
    } catch (err) {
      if (attempt < 2) {
        setTimeout(() => {
          void fetchBootstrap(attempt + 1);
        }, 900);
        return;
      }
      setBootError(err instanceof Error ? err.message : 'تعذر الاتصال بخادم وصلها.');
      setBootLoading(false);
    }
  }, []);

  const fetchAuthMe = useCallback(async () => {
    try {
      const me = await apiRequest<AuthMeResponse>('/api/auth/me');
      setCurrentUser(me.user);
      setCurrentDriver(me.driver || null);
    } catch {
      setCurrentUser(null);
      setCurrentDriver(null);
    }
  }, []);

  useEffect(() => {
    const timer = setTimeout(() => setShowSplash(false), 900);
    void fetchBootstrap();
    void fetchAuthMe();
    return () => clearTimeout(timer);
  }, [fetchBootstrap, fetchAuthMe]);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (fbUser) => {
      setFirebaseEmail(fbUser?.email || null);
    });
    return () => unsub();
  }, []);

  useEffect(() => {
    const onQuota = () => setMapsQuotaExceeded(true);
    window.addEventListener('gmp-quota-exceeded', onQuota);
    return () => window.removeEventListener('gmp-quota-exceeded', onQuota);
  }, []);

  useEffect(() => {
    const evtSource = new EventSource(resolveApiUrl('/api/events'));
    const handleUpdate = () => {
      setRealtimeTick((t) => t + 1);
      void fetchBootstrap();
    };
    evtSource.addEventListener('update', handleUpdate);
    return () => {
      evtSource.removeEventListener('update', handleUpdate);
      evtSource.close();
    };
  }, [fetchBootstrap]);

  const activeMeta = APP_MODE_META[appMode];
  const coveredZonesCount = zones.filter((z) => z.isActive && z.isCovered).length;

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900 pb-8">
      <SplashScreen visible={showSplash} mode={appMode} />

      {mapsQuotaExceeded && (
        <div
          dir="ltr"
          className="bg-amber-50 border-b border-amber-200 text-amber-900 px-4 py-2.5 text-xs md:text-sm text-center sticky top-0 z-50 shadow-sm"
        >
          <span>
            Google Maps Platform quota reached. If you are the app owner, visit{' '}
            <a
              href="https://developers.google.com/maps/ai/ai-studio?utm_campaign=gmp_mcp_codeassist_v1_aistudio#quota_exceeded_errors"
              target="_blank"
              rel="noopener noreferrer"
              className="underline font-semibold text-amber-950 hover:text-amber-800"
            >
              maps developer site
            </a>{' '}
            for instructions to update your account.
          </span>
        </div>
      )}

      {/* Top App Header */}
      <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            {!IS_LOCKED_APK_BUILD && appMode !== 'hub' && (
              <button
                type="button"
                onClick={() => navigateToMode('hub')}
                title="العودة إلى بوابة التطبيقات الثلاثة"
                className="min-h-[38px] inline-flex items-center gap-1.5 rounded-xl border border-slate-200 bg-slate-50 px-3 text-xs font-bold text-slate-700 hover:bg-slate-100 shrink-0 cursor-pointer"
              >
                <ArrowRight className="w-4 h-4" />
                <span className="hidden sm:inline">التطبيقات</span>
              </button>
            )}

            <button
              type="button"
              onClick={() => (!IS_LOCKED_APK_BUILD ? navigateToMode('hub') : undefined)}
              className={`flex items-center gap-2.5 min-w-0 ${
                !IS_LOCKED_APK_BUILD ? 'cursor-pointer' : 'cursor-default'
              }`}
            >
              <img
                src={WASELHA_LOGO_URL}
                alt="وصلها"
                className="w-9 h-9 rounded-xl object-contain border border-slate-100 shrink-0"
              />
              <div className="text-right min-w-0">
                <div className="text-base sm:text-lg font-extrabold tracking-tight text-slate-900 truncate">
                  {appMode === 'hub' ? settings.appName : activeMeta.titleAr}
                </div>
                <div
                  className="text-[10px] font-bold tracking-wider text-sky-700 uppercase truncate"
                  style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
                >
                  {activeMeta.subtitleEn}
                </div>
              </div>
            </button>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <PWAInstallButton onShowAndroidGuide={() => setShowAndroidModal(true)} />
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 w-full max-w-7xl mx-auto px-4 sm:px-6 py-6">
        {bootError && (
          <div className="mb-6 rounded-2xl border border-rose-200 bg-rose-50 p-4 flex items-center justify-between gap-4">
            <p className="text-sm font-semibold text-rose-800">{bootError}</p>
            <button
              type="button"
              onClick={() => void fetchBootstrap()}
              className="min-h-[38px] px-4 rounded-xl bg-rose-600 text-white text-xs font-bold hover:bg-rose-700 cursor-pointer"
            >
              إعادة المحاولة
            </button>
          </div>
        )}

        {settings.maintenanceMode && appMode !== 'manager' && appMode !== 'hub' ? (
          <div className="max-w-lg mx-auto rounded-3xl border border-amber-200 bg-amber-50 p-8 text-center space-y-3 my-8">
            <div className="w-14 h-14 rounded-2xl bg-amber-100 text-amber-700 flex items-center justify-center mx-auto">
              <Wrench className="w-7 h-7" />
            </div>
            <h2 className="text-xl font-extrabold text-amber-950">النظام في وضع الصيانة المؤقت</h2>
            <p className="text-sm text-amber-800 leading-relaxed">
              تقوم إدارة وصلها حالياً بإجراء تحديثات فنية لتحسين الخدمة. يرجى المحاولة بعد قليل.
            </p>
            {settings.supportPhone && (
              <p className="text-xs font-bold text-amber-900 font-mono-num">
                هاتف الدعم: {settings.supportPhone}
              </p>
            )}
          </div>
        ) : bootLoading ? (
          <div className="rounded-3xl border border-slate-200 bg-white p-12 text-center space-y-3">
            <div className="w-8 h-8 rounded-full border-3 border-sky-200 border-t-sky-600 animate-spin mx-auto" />
            <p className="text-sm font-semibold text-slate-600">جاري الاتصال بسيرفر وصلها...</p>
          </div>
        ) : (
          <>
            {appMode === 'hub' && (
              <div className="space-y-8">
                {/* Hub Hero */}
                <section className="rounded-3xl bg-gradient-to-l from-sky-700 via-sky-600 to-cyan-600 text-white p-6 sm:p-8 shadow-sm">
                  <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
                    <div className="space-y-2.5 max-w-2xl">
                      <span className="inline-flex items-center gap-1.5 rounded-xl bg-white/15 px-3 py-1 text-xs font-bold text-cyan-100">
                        <CheckCircle2 className="w-4 h-4" />
                        منصة توصيل حر متصلة بسيرفر وقاعدة بيانات واحدة لحظياً
                      </span>
                      <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
                        منظومة وصلها — ثلاثة تطبيقات للتوصيل الحر
                      </h1>
                      <p className="text-sm text-sky-50 leading-relaxed">
                        منصة توصيل حر تربط أصحاب المحلات والمطاعم والأفراد بالمندوبين لتوصيل
                        الأغراض والطرود من أي نقطة استلام إلى أي نقطة تسليم، بتسعيرة مناطق كاملة
                        تحت سيطرة الإدارة.
                      </p>
                    </div>

                    <div className="grid grid-cols-3 gap-3 shrink-0">
                      <div className="rounded-2xl bg-white/15 backdrop-blur-sm px-4 py-3 text-center">
                        <div className="text-2xl font-extrabold font-mono-num">
                          {coveredZonesCount}
                        </div>
                        <div className="text-[11px] text-cyan-100 font-semibold">منطقة مغطاة</div>
                      </div>
                      <div className="rounded-2xl bg-white/15 backdrop-blur-sm px-4 py-3 text-center">
                        <div className="text-2xl font-extrabold font-mono-num">
                          {routeRates.length}
                        </div>
                        <div className="text-[11px] text-cyan-100 font-semibold">مسار بين مناطق</div>
                      </div>
                      <div className="rounded-2xl bg-white/15 backdrop-blur-sm px-4 py-3 text-center">
                        <div className="text-2xl font-extrabold font-mono-num">3</div>
                        <div className="text-[11px] text-cyan-100 font-semibold">تطبيقات مستقلة</div>
                      </div>
                    </div>
                  </div>
                </section>

                {/* The 3 Dedicated Android Apps */}
                <section className="grid grid-cols-1 md:grid-cols-3 gap-5">
                  {/* 1. Customer & Shops App */}
                  <div className="rounded-3xl border border-slate-200 bg-white p-6 flex flex-col justify-between gap-5 shadow-xs hover:border-sky-300 transition-colors">
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <div className="w-12 h-12 rounded-2xl bg-sky-50 text-sky-600 flex items-center justify-center">
                          <Package className="w-6 h-6" />
                        </div>
                        <span
                          dir="ltr"
                          className="text-[11px] font-mono-num font-bold text-slate-400"
                        >
                          iq.waselha.customer
                        </span>
                      </div>
                      <div>
                        <h2 className="text-xl font-extrabold text-slate-900">
                          وصلها للزبائن والمحلات
                        </h2>
                        <p
                          className="text-xs font-bold text-sky-700 mt-0.5"
                          style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
                        >
                          WASELHA CUSTOMER
                        </p>
                      </div>
                      <p className="text-sm text-slate-600 leading-relaxed">
                        إنشاء طلب توصيل حر للأفراد أو المحلات والمطاعم، تحديد موقعي الاستلام
                        والتسليم على Google Maps، معرفة الأجرة قبل التأكيد، ومتابعة المندوب.
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => navigateToMode('customer')}
                      className="w-full min-h-[46px] rounded-xl bg-sky-600 text-white font-bold text-sm hover:bg-sky-700 cursor-pointer"
                    >
                      فتح تطبيق الزبائن والمحلات
                    </button>
                  </div>

                  {/* 2. Driver App */}
                  <div className="rounded-3xl border border-slate-200 bg-white p-6 flex flex-col justify-between gap-5 shadow-xs hover:border-cyan-300 transition-colors">
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <div className="w-12 h-12 rounded-2xl bg-cyan-50 text-cyan-700 flex items-center justify-center">
                          <Truck className="w-6 h-6" />
                        </div>
                        <span
                          dir="ltr"
                          className="text-[11px] font-mono-num font-bold text-slate-400"
                        >
                          iq.waselha.driver
                        </span>
                      </div>
                      <div>
                        <h2 className="text-xl font-extrabold text-slate-900">وصلها للمندوبين</h2>
                        <p
                          className="text-xs font-bold text-cyan-700 mt-0.5"
                          style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
                        >
                          WASELHA DRIVER
                        </p>
                      </div>
                      <p className="text-sm text-slate-600 leading-relaxed">
                        استقبال طلبات التوصيل الحر، معاينة موقع الاستلام والتسليم وأجرة التوصيل،
                        قبول أو رفض الطلب، تحديث مراحل التوصيل، وحساب الأرباح (75%).
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => navigateToMode('driver')}
                      className="w-full min-h-[46px] rounded-xl bg-cyan-600 text-white font-bold text-sm hover:bg-cyan-700 cursor-pointer"
                    >
                      فتح تطبيق المندوبين
                    </button>
                  </div>

                  {/* 3. Manager App */}
                  <div className="rounded-3xl border border-slate-200 bg-white p-6 flex flex-col justify-between gap-5 shadow-xs hover:border-slate-400 transition-colors">
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <div className="w-12 h-12 rounded-2xl bg-slate-900 text-white flex items-center justify-center">
                          <ShieldCheck className="w-6 h-6" />
                        </div>
                        <span
                          dir="ltr"
                          className="text-[11px] font-mono-num font-bold text-slate-400"
                        >
                          iq.waselha.manager
                        </span>
                      </div>
                      <div>
                        <h2 className="text-xl font-extrabold text-slate-900">وصلها للإدارة</h2>
                        <p
                          className="text-xs font-bold text-slate-600 mt-0.5"
                          style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
                        >
                          WASELHA MANAGER
                        </p>
                      </div>
                      <p className="text-sm text-slate-600 leading-relaxed">
                        صلاحية حصرية للمدير العام للتحكم بأسماء المناطق وأجورها، جدول الانتقال بين
                        منطقتين، أسعار المسافات البعيدة، متابعة الطلبات وأرباح 25%/75%.
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => navigateToMode('manager')}
                      className="w-full min-h-[46px] rounded-xl bg-slate-900 text-white font-bold text-sm hover:bg-slate-800 cursor-pointer"
                    >
                      فتح تطبيق الإدارة
                    </button>
                  </div>
                </section>

                {/* Direct Signed Android APK Downloads */}
                <section className="rounded-3xl border border-sky-200 bg-gradient-to-br from-white to-sky-50/60 p-6 space-y-4">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div>
                      <h3 className="font-extrabold text-base text-slate-900 flex items-center gap-2">
                        <Download className="w-5 h-5 text-sky-600" />
                        <span>تنزيل تطبيقات الأندرويد الموقّعة مباشرة (APK)</span>
                      </h3>
                      <p className="text-xs text-slate-600 mt-1">
                        ملفات تثبيت حقيقية وموقّعة متصلة بسيرفر وصلها المشترك وقاعدة البيانات الحية.
                      </p>
                    </div>
                    <a
                      href={resolveApiUrl('/downloads/waselha-project-backup.tar.gz')}
                      download="waselha-project-backup.tar.gz"
                      className="min-h-[38px] inline-flex items-center gap-2 rounded-xl border border-emerald-200 bg-emerald-50 px-3.5 text-xs font-bold text-emerald-800 hover:bg-emerald-100"
                    >
                      <Download className="w-4 h-4" />
                      <span>النسخة الكاملة للكود وقاعدة البيانات</span>
                    </a>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <a
                      href={resolveApiUrl('/downloads/WASELHA%20CUSTOMER.apk')}
                      download="WASELHA CUSTOMER.apk"
                      className="min-h-[54px] flex items-center justify-between rounded-2xl border border-sky-200 bg-white px-4 py-3 text-xs font-bold text-sky-900 hover:border-sky-400 hover:bg-sky-50/70 transition-colors"
                    >
                      <div>
                        <div className="text-sm font-extrabold">1. تطبيق الزبائن والمحلات</div>
                        <div dir="ltr" className="text-[11px] font-mono-num text-sky-700 mt-0.5">
                          WASELHA CUSTOMER.apk
                        </div>
                      </div>
                      <Download className="w-4 h-4 text-sky-600 shrink-0" />
                    </a>

                    <a
                      href={resolveApiUrl('/downloads/WASELHA%20DRIVER.apk')}
                      download="WASELHA DRIVER.apk"
                      className="min-h-[54px] flex items-center justify-between rounded-2xl border border-cyan-200 bg-white px-4 py-3 text-xs font-bold text-cyan-900 hover:border-cyan-400 hover:bg-cyan-50/70 transition-colors"
                    >
                      <div>
                        <div className="text-sm font-extrabold">2. تطبيق المندوبين</div>
                        <div dir="ltr" className="text-[11px] font-mono-num text-cyan-700 mt-0.5">
                          WASELHA DRIVER.apk
                        </div>
                      </div>
                      <Download className="w-4 h-4 text-cyan-600 shrink-0" />
                    </a>

                    <a
                      href={resolveApiUrl('/downloads/WASELHA%20MANAGER.apk')}
                      download="WASELHA MANAGER.apk"
                      className="min-h-[54px] flex items-center justify-between rounded-2xl border border-slate-300 bg-white px-4 py-3 text-xs font-bold text-slate-900 hover:border-slate-500 hover:bg-slate-50 transition-colors"
                    >
                      <div>
                        <div className="text-sm font-extrabold">3. تطبيق المدير</div>
                        <div dir="ltr" className="text-[11px] font-mono-num text-slate-600 mt-0.5">
                          WASELHA MANAGER.apk
                        </div>
                      </div>
                      <Download className="w-4 h-4 text-slate-700 shrink-0" />
                    </a>
                  </div>
                </section>

                {/* Live Coverage Zones & Inter-Zone Routes Summary */}
                <section className="rounded-3xl border border-slate-200 bg-white p-6 space-y-4">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2">
                      <MapPin className="w-4 h-4 text-sky-600" />
                      <span>مناطق التغطية والأسعار المعتمدة من الإدارة ({coveredZonesCount})</span>
                    </h3>
                    <button
                      type="button"
                      onClick={() => setShowAndroidModal(true)}
                      className="inline-flex items-center gap-1.5 text-xs font-bold text-sky-700 hover:underline cursor-pointer"
                    >
                      <Smartphone className="w-4 h-4" />
                      <span>دليل التثبيت على أندرويد وحزم APK</span>
                    </button>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    {zones.map((z) => (
                      <div
                        key={z.id}
                        className={`rounded-xl border px-3 py-2 text-xs ${
                          z.isCovered
                            ? 'border-sky-200 bg-sky-50/70 text-sky-900'
                            : 'border-slate-200 bg-slate-100 text-slate-500'
                        }`}
                      >
                        <span className="font-bold">{z.name}</span>
                        <span className="text-[11px] text-slate-600 mr-1.5 font-mono-num">
                          (
                          {z.pricingMode === 'fixed'
                            ? formatIqd(z.fixedFeeIqd)
                            : `${formatIqd(z.baseFeeIqd)} + ${formatIqd(z.perKmFeeIqd)}/كم`}
                          )
                        </span>
                      </div>
                    ))}
                    {zones.length === 0 && (
                      <span className="text-xs text-slate-500">لا توجد مناطق مضافة بعد.</span>
                    )}
                  </div>
                </section>
              </div>
            )}

            {appMode === 'customer' && (
              <CustomerSection
                zones={zones}
                routeRates={routeRates}
                settings={settings}
                mapsApiKey={mapsApiKey}
                realtimeTick={realtimeTick}
                currentUser={currentUser}
                onAuthChange={fetchAuthMe}
              />
            )}

            {appMode === 'driver' && (
              <DriverSection
                currentUser={currentUser}
                currentDriver={currentDriver}
                mapsApiKey={mapsApiKey}
                realtimeTick={realtimeTick}
                onAuthChange={fetchAuthMe}
              />
            )}

            {appMode === 'manager' && (
              <AdminSection
                currentUser={currentUser}
                realtimeTick={realtimeTick}
                firebaseEmail={firebaseEmail}
                mapsApiKey={mapsApiKey}
                onAuthChange={fetchAuthMe}
                onSettingsUpdated={fetchBootstrap}
              />
            )}
          </>
        )}
      </main>

      {/* Android Installation & 3-APK Packaging Guide Modal */}
      {showAndroidModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4 backdrop-blur-sm">
          <div className="w-full max-w-lg rounded-3xl bg-white p-6 shadow-xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-extrabold text-slate-900">
                تثبيت تطبيقات وصلها الثلاثة على الأندرويد
              </h3>
              <button
                type="button"
                onClick={() => setShowAndroidModal(false)}
                className="w-9 h-9 rounded-xl bg-slate-100 text-slate-600 flex items-center justify-center hover:bg-slate-200 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="text-sm text-slate-600 space-y-3 leading-relaxed">
              <div className="rounded-2xl bg-sky-50 border border-sky-200 p-3.5 space-y-1.5">
                <p className="font-bold text-sky-900">1. التثبيت المباشر على هاتف أندرويد:</p>
                <p className="text-xs text-sky-900">
                  افتح رابط التطبيق المطلوب (<code dir="ltr">/customer</code> أو{' '}
                  <code dir="ltr">/driver</code> أو <code dir="ltr">/manager</code>) في Google
                  Chrome ثم اختر <strong>تثبيت التطبيق (Install App)</strong> ليظهر بأيقونة مستقلة
                  لكل تطبيق على الهاتف.
                </p>
              </div>

              <div className="rounded-2xl bg-slate-50 border border-slate-200 p-3.5 space-y-2">
                <p className="font-bold text-slate-900">
                  2. تنزيل ملفات الأندرويد الموقّعة مباشرة (APK):
                </p>
                <div className="grid grid-cols-1 gap-2">
                  <a
                    href={resolveApiUrl('/downloads/WASELHA%20CUSTOMER.apk')}
                    download="WASELHA CUSTOMER.apk"
                    className="min-h-[40px] flex items-center justify-between rounded-xl border border-sky-200 bg-white px-3 text-xs font-bold text-sky-800 hover:bg-sky-50"
                  >
                    <span>1. تطبيق الزبائن والمحلات</span>
                    <span dir="ltr" className="font-mono-num">
                      WASELHA CUSTOMER.apk
                    </span>
                  </a>
                  <a
                    href={resolveApiUrl('/downloads/WASELHA%20DRIVER.apk')}
                    download="WASELHA DRIVER.apk"
                    className="min-h-[40px] flex items-center justify-between rounded-xl border border-cyan-200 bg-white px-3 text-xs font-bold text-cyan-800 hover:bg-cyan-50"
                  >
                    <span>2. تطبيق المندوبين</span>
                    <span dir="ltr" className="font-mono-num">
                      WASELHA DRIVER.apk
                    </span>
                  </a>
                  <a
                    href={resolveApiUrl('/downloads/WASELHA%20MANAGER.apk')}
                    download="WASELHA MANAGER.apk"
                    className="min-h-[40px] flex items-center justify-between rounded-xl border border-slate-300 bg-white px-3 text-xs font-bold text-slate-900 hover:bg-slate-100"
                  >
                    <span>3. تطبيق المدير</span>
                    <span dir="ltr" className="font-mono-num">
                      WASELHA MANAGER.apk
                    </span>
                  </a>
                  <a
                    href={resolveApiUrl('/downloads/waselha-project-backup.tar.gz')}
                    download="waselha-project-backup.tar.gz"
                    className="min-h-[38px] flex items-center justify-between rounded-xl border border-emerald-200 bg-emerald-50 px-3 text-xs font-bold text-emerald-800 hover:bg-emerald-100"
                  >
                    <span>النسخة الكاملة للكود وقاعدة البيانات</span>
                    <span dir="ltr" className="font-mono-num">
                      waselha-project-backup.tar.gz
                    </span>
                  </a>
                </div>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setShowAndroidModal(false)}
              className="w-full min-h-[44px] rounded-xl bg-sky-600 text-white font-bold text-sm hover:bg-sky-700 cursor-pointer"
            >
              فهمت
            </button>
          </div>
        </div>
      )}

      <OfflineIndicator />
    </div>
  );
}
